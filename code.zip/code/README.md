# TourismNLG: A Multi-lingual Generative Benchmark for the Tourism Domain ✈️🏖️ 

### Environment Setup
1. Download this repository to your local machine.
2. Python version used: Python 3.8.5  
Conda version used: 10.2 
3. Create a python virtual environment and activate it.
```bash
python3 -m venv env
source env/bin/activate
```
4. Install all the required libraries and modules  
```bash
pip3 install -r requirements.txt
``` 

### Instructions for Running
1. Download the dataset and model(s) from the links available in our paper.
2. To run end-to-end versions of our experiments (pretraining, finetuning and evaluation), please use the scripts available in the _scripts_ directory.
3. You may also run finetuning experiments via the command line; for example:
```bash
### Multi-task finetuning tourBartB
python -m torch.distributed.launch --nproc_per_node=4 tourBart/main.py \
--data_dir ${baseDir}/data \
--output_dir ${output_dir} \
--train_batch_size 16 \
--eval_batch_size 32 \
--lr 3e-6 \
--epochs 3 \
--model_chkp ${baseDir}/models/tourBartB \
--max_seq_len 256 \
--tasks "infobox-2-para,para-2-infobox,blog-title-generation,forum-title-generation,answer-generation" \
--do_train 2>&1 |tee -a logs/${date}_finetuned_output_dir_tourBartB.log
```
4. You can also run the evaluation scripts through the command line; for example:
```bash
### Generate outputs
python tourBart/main.py \
--data_dir ${baseDir}/data \
--output_dir ${output_dir} \
--model_chkp ${baseDir}/outputs/${date}_finetuned_output_dir_tourBartB \
--eval_batch_size 1 \
--max_seq_len 256 \
--tasks "infobox-2-para,para-2-infobox,blog-title-generation,forum-title-generation,answer-generation" \
--beam_size 1 \
--early_stopping \
--no_repeat_ngram_size 3 \
--do_test 2>&1 |tee -a logs/${date}_output_dir_tourBartB.log
```
```bash
### Compute metrics
python evaluation/evaluate_metrics.py ${output_dir}/output_answer-generation.json ${results_file}
```
