import spacy
from nltk.tag import pos_tag
import en_core_web_sm
from spacy.language import Language
from spacy_langdetect import LanguageDetector
import json
import sys, traceback

nlp = spacy.load('en_core_web_sm')
Language.factory("language_detector", func=get_lang_detector)
nlp.add_pipe('language_detector', last=True)


filename = "data/TravelWeb/dev.tsv" # Change the filename here depending on the task. Preprocessing will also change accordingly.
ctr = 0
landict = {}
mapfile = open('travelweb_devmap.txt','w')

with open(filename, "r", encoding="utf-8", errors="replace") as fp:
    for line in fp:
        ctr+=1
        original_line = line
        line = json.loads(line)
        line = line["text"].strip()
        line = line.replace("\n"," ")
        # qtitle = line['question']['title'].strip()
        # qtext = line['question']['fulltext'].strip()
        try:
            line_len = min(len(line.split(' ')), 150)
            # qline = ' '.join(qtext.split(' ')[:line_len])
            line = ' '.join(line.split(' ')[:line_len])
            # line = qtitle + ' ' + qtext
            print(ctr)
            doc = nlp(line)
            # print(doc._.language)
            detected_language = doc._.language['language']
            if detected_language not in landict.keys():
                landict[detected_language] = 0
            landict[detected_language]+=1
            mapfile.write(str(doc._.language['language'])+'\n')
            
        except Exception as e:
            traceback.print_exc(file=sys.stdout)
            print(e)

        if ctr%5000==0:
            wfile = open('intermediatetripdev.txt','a')
            wfile.write(str(ctr)+'\n')
            for key in landict.keys():
                line = key + '\t' + str(landict[key]) + '\n'
                wfile.write(line)
        
    fp.close()

wfile = open('travelwebdev.txt','w')
for key in landict.keys():
    line = key + '\t' + str(landict[key]) + '\n'
    wfile.write(line)