import math
num_dict = {}
percent_dict = {}

modes = ['test','dev','finetune','pretrain']
# modes = ['dev','test','train']
counter = 0

tripoverall = []

rfile = open('overalltripmap.txt','r')
for line in rfile:
    if line.strip()!='':
        tripoverall.append(line.strip())

tripfile = 'data/TripAdvisorQnA/overall.tsv'
file = open(tripfile,'r')
idx = 0
for line in file:
    lang = tripoverall[idx]
    idx+=1
    newfile = open('data/TripAdvisorQnA/langs/' + lang + '.tsv','a')
    if lang not in num_dict.keys():
        num_dict[lang]=0
    num_dict[lang]+=1
    newfile.write(line)
    counter+=1

print(num_dict)

for key in num_dict.keys():
    percent_dict[key] = num_dict[key]/counter

# print(percent_dict)

test_dict = {}
for lang in percent_dict:
    test_dict[lang] = int(percent_dict[lang]*7500)

sum = 0
for key in test_dict.keys():
    if test_dict[key]==0:
        test_dict[key]+=1

for value in test_dict.values():
    sum+=value

# if sum<7500:
#     while sum<7500:
#         for lang in test_dict.keys():
#             test_dict[lang]+=1
#             sum+=1
#             if sum==7500:
#                 break
# else:
#     while sum>7500:
#         for lang in test_dict.keys():
#             test_dict[lang]-=1
#             sum-=1
#             if sum==7500:
#                 break


for lang in num_dict.keys():
    ctr = 0
    rfile = open('data/TripAdvisorQnA/langs/'+lang+'.tsv','r')
    wfile = open('data/TripAdvisorQnA/test.tsv','a')
    print(lang,end=',')
    for line in rfile:
        wfile.write(line)
        ctr+=1
        if ctr==test_dict[lang]:
            print(str(ctr),end=',')
            # print(ctr)
            # wfile.close()
            wfile = open('data/TripAdvisorQnA/dev.tsv','a')
        elif ctr==(test_dict[lang]*2):
            print(str(ctr-test_dict[lang]),end=',')
            # wfile.close()
            wfile = open('data/TripAdvisorQnA/finetune.tsv','a')
        elif ctr==((test_dict[lang]*2)+int((num_dict[lang]-test_dict[lang]*2)/2)):
            print(str(int((num_dict[lang]-test_dict[lang]*2)/2)),end=',')
            # wfile.close()
            wfile = open('data/TripAdvisorQnA/pretrain.tsv','a')
    print(max(0,num_dict[lang]-((test_dict[lang]*2)+int((num_dict[lang]-test_dict[lang]*2)/2))))