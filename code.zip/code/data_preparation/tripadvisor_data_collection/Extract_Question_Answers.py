# Extract the questions and their answers

from bs4 import BeautifulSoup
import re
import os
import time
import json
from selenium import webdriver
from selenium.webdriver import FirefoxOptions
import pickle
import os
import json
import sys

country = str(sys.argv[1])

options = FirefoxOptions()
options.add_argument("--headless")
driver = webdriver.Firefox(executable_path='./geckodriver', options=options)

halt_after = 50
sleep_time = 5

class SeleniumError(Exception):
    pass

def get_post_info(postDiv, isReply=True):
    
    returnDict = {}
    try:
        username = postDiv.find_elements_by_css_selector('div.username')[0].find_elements_by_css_selector('span')[0]\
        .get_attribute('innerHTML')
    except:
        username = ""
    try:
        location = postDiv.find_elements_by_css_selector('div.location')[0].get_attribute('innerHTML')
    except:
        location = ""
    try:
        level = postDiv.find_elements_by_css_selector('div[class^="levelBadge"]')[0].get_attribute('class').split(' ')[-1]
    except:
        level = 0
    try:
        numposts = postDiv.find_element_by_css_selector('div[class="postBadge badge"]').\
            find_element_by_css_selector('span.badgeText').get_attribute('innerHTML')
    except:
        numposts = 0
    if isReply:
        try:
            numReviews = postDiv.find_element_by_css_selector('div[class="reviewerBadge badge"]').\
            find_element_by_css_selector('span.badgeText').get_attribute('innerHTML') 
        except:
            numReviews = 0
        try:
            votes = postDiv.find_element_by_css_selector('div[class="helpfulVotesBadge badge"]').\
            find_element_by_css_selector('span.badgeText').get_attribute('innerHTML')
        except:
            votes = 0
        returnDict['numReviews'] = numReviews
        returnDict['votes'] = votes
    
    if not isReply:
        title = postDiv.find_element_by_css_selector('span.topTitleText').get_attribute('innerHTML')
        returnDict['title'] = title
    
    date = postDiv.find_element_by_css_selector('div.postDate').get_attribute('innerHTML')
    
    postbody = postDiv.find_element_by_css_selector('div.postBody')
    content = postbody.find_elements_by_css_selector('p')
    fulltext = ""

    for para in content:
        temp = para.get_attribute('innerHTML')
        soup = BeautifulSoup(temp, 'html.parser')

        for node in soup.descendants:
            if node.parent.name != '[document]':
                continue
            if node.name == 'script':
                continue
            if not node.name:
                fulltext += node
            elif node.name == 'a' :
                fulltext += '[{}] {}'.format(node['href'],node.contents[0])

    returnDict['username'] = username
    returnDict['location'] = location
    returnDict['level'] = level
    returnDict['numposts'] = numposts
    returnDict['date'] = date
    returnDict['fulltext'] = fulltext
    return returnDict

def get_answers(url):
     
    driver.get(url)

    ans = []
    replies = driver.find_elements_by_css_selector('div[class^="post "]')
    for i in range(1,len(replies)):
        try:
            ans.append(get_post_info(replies[i]))
        except:
            pass
            
    return ans
 
def scrape_ques_pages(url):
    global cur_req, driver
    
    driver.get(url)

    firstPost = driver.find_element_by_css_selector('div.firstPostBox')
    ques = get_post_info(firstPost,False)
    try:
        num_replies = driver.find_element_by_css_selector('div.replies').find_element_by_css_selector('h5').\
        get_attribute('innerHTML')
        num_replies = int(num_replies.strip(" ").split(" ")[0])
    except:
        num_replies = 1
        
    if num_replies == 1:
        try:
            html  = driver.find_element_by_css_selector('div.pgCount').get_attribute('innerHTML')
            soup = BeautifulSoup(html, 'html.parser')
            for node in soup.descendants:
                if node.parent.name != '[document]':
                    continue
                if not node.name:
                    if 'replies' in node:
                        num_replies = int(node.strip(' ').split(' ')[0])
        except Exception as e:
            print("Could not find total replies, scraping the first page.")
    ans = []
    
    num_pages = num_replies//10
    split_url = url.split('-')
    part1 = "-".join(split_url[0:4])
    part2 = "-".join(split_url[4:])
    for i in range(num_pages+1):
        try:
            if i == 0:
                ans.extend(get_answers(url))
            else:
                ans.extend(get_answers("{}-o{}-{}".format(part1,i*10,part2)))
            cur_req += 1
        except:
            pass
        if cur_req%halt_after == 0:
            time.sleep(sleep_time)
            driver.delete_all_cookies()
            driver.quit()
            driver = webdriver.Firefox(executable_path='./geckodriver', options=options)

    return {
        'question' : ques,
        'answers': ans
    }



global cur_req 
cur_req = 1

with open('./post_urls/'+country+'_ques_urls.pkl','rb+') as f:
        pages = pickle.load(f)

try:
    os.mkdir('./json_data/'+country+'_question_data/')
except:
    pass
files = os.listdir('./json_data/'+country+'_question_data/')

for topic in pages:
    if topic +'.json' in files:
        with open(os.path.join('./json_data/'+country+'_question_data/',topic+'.json'),'r+', encoding='utf-8') as f:
            data = json.load(f)
    else:
        data = {}
    for i, url in enumerate(pages[topic]):
        split_url = url.split('-')
        code = "-".join(split_url[1:4])
        if code in data:
            continue
        print("Starting the topic: {}, Post:{}/{}".format(topic, i+1, len(pages[topic])))
        try:
            data[code] = scrape_ques_pages(url)
        except Exception as e:
            if code in data:
                del data[code]
            if e == KeyboardInterrupt:
                print("Script Stopped")
                exit(0)
            else:
                print("Error {} Occured, Restart the Script".format(e))

        with open(os.path.join('./json_data/'+country+'_question_data/',topic+'.json'),'w+', encoding='utf-8') as f:
            json.dump(data,f,ensure_ascii=False)