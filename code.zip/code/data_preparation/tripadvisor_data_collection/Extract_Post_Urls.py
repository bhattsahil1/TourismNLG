# Extract the urls for questions on thr forum

from bs4 import BeautifulSoup
import re
import os
import time
import json
from click import option
from selenium import webdriver
from selenium.webdriver import FirefoxOptions
import pickle
import sys

country = str(sys.argv[1])

options = FirefoxOptions()
options.add_argument("--headless")
driver = webdriver.Firefox(executable_path='./geckodriver', options=options)


max_pages = 500  # maximum number of pages to be scraped for each topic, per page 20 questions
halt_after = 50    # wait for some time after these many requests to avoid blocking
sleep_time = 5

def get_topic_urls():
    urls = []
    driver.get('https://www.tripadvisor.'+country+'/ListForums-g1-World.html')    
    results = driver.find_elements_by_css_selector('table.forumtopic')
    topics = results[0].find_elements_by_css_selector('tr')
    print(topics)
    for i in range(1,len(topics)):
        link = topics[i].find_elements_by_css_selector('a')  
        num_topics = topics[i].find_elements_by_css_selector('td.top')[0].get_attribute('innerHTML')
        num_topics = "".join(num_topics.split(','))
        num_topics = "".join(num_topics.split('.'))
        num_topics = "".join(num_topics.split('&nbsp;'))
        num_topics = int(re.sub("[^0-9]","", num_topics))
        print(num_topics)
        # num_topics = int(num_topics)
        url = link[0].get_attribute('href')    
        topic = link[0].get_attribute('innerHTML')
        urls.append([url, topic, num_topics])
    return urls

print("Extracted Topics Names")

def get_question_urls(url):
    driver.get(url)    
    forum = driver.find_elements_by_css_selector('table.topics')    
    ques = forum[0].find_elements_by_css_selector('tr')    
    posts = []
    for i in range(1,len(ques)):
        try:
            url = ques[i].find_elements_by_css_selector('b')[0].find_elements_by_css_selector('a')[0].get_attribute('href') 
            posts.append(url)
        except Exception as e:
            pass
    return posts

urls = get_topic_urls()


try:
    with open('./post_urls/'+country+'_ques_urls.pkl','rb+') as f:
        pages = pickle.load(f)
except:
    pages = {}
cur_req = 1

for item in urls:
    ques = []
    url = item[0]
    topic = item[1]
    if topic in pages and len(pages[topic]):
        continue
    part1 = "-".join(url.split('-')[0:-1])
    part2 = url.split('-')[-1]
    try:
        num_pages = min(max_pages, item[2]//20)
        print("Scraping {} pages, {} questions for {}".format(num_pages, min(max_pages*20,item[2]), topic))
        for i in range(num_pages+1):
            try:
                if i == 0:
                    ques.extend(get_question_urls(part1+"-"+part2))
                else:
                    ques.extend(get_question_urls(part1+"-o{}-".format(i*20)+part2))
                cur_req += 1
            except Exception as e:
                if e == KeyboardInterrupt:
                    print("Stopping")
                    exit(0)
                else:
                    print(e)

            if cur_req%halt_after == 0:
                time.sleep(sleep_time)
                driver.delete_all_cookies()
                driver.quit()
                driver = webdriver.Firefox(executable_path='./geckodriver', options=options)

        print("Scraped {} questions".format(len(set(ques))))
        pages[topic] = ques
        with open('./post_urls/'+country+'_ques_urls.pkl','wb+') as f:
            pickle.dump(pages,f)
    except Exception as e:
        if e == KeyboardInterrupt:
                print("Script Stopped")
                exit(0)
        else:
            print("Error Occured, Restart the Script")