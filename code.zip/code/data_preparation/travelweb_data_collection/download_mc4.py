import json
import os
import re
import marisa_trie
import sys
from tqdm import tqdm
from functools import partial
from multiprocessing import Pool, cpu_count, TimeoutError
import gzip
import time
import wget
import shutil
from glob import glob

_URL = "https://github.com/allenai/allennlp/discussions/5056"

_DATA_URL = "https://huggingface.co/datasets/allenai/c4/resolve/1ddc917116b730e1859edef32896ec5c16be51d0/multilingual/c4-{language}{split_suffix}.tfrecord-{index:05d}-of-{n_shards:05d}.json.gz"

_LANGUAGES = [
    "en",
    "af",
    "am",
    "ar",
    "az",
    "be",
    "bg",
    "bg-Latn",
    "bn",
    "ca",
    "ceb",
    "co",
    "cs",
    "cy",
    "da",
    "de",
    "el",
    "el-Latn",
    "eo",
    "es",
    "et",
    "eu",
    "fa",
    "fi",
    "fil",
    "fr",
    "fy",
    "ga",
    "gd",
    "gl",
    "gu",
    "ha",
    "haw",
    "hi",
    "hi-Latn",
    "hmn",
    "ht",
    "hu",
    "hy",
    "id",
    "ig",
    "is",
    "it",
    "iw",
    "ja",
    "ja-Latn",
    "jv",
    "ka",
    "kk",
    "km",
    "kn",
    "ko",
    "ku",
    "ky",
    "la",
    "lb",
    "lo",
    "lt",
    "lv",
    "mg",
    "mi",
    "mk",
    "ml",
    "mn",
    "mr",
    "ms",
    "mt",
    "my",
    "ne",
    "nl",
    "no",
    "ny",
    "pa",
    "pl",
    "ps",
    "pt",
    "ro",
    "ru",
    "ru-Latn",
    "sd",
    "si",
    "sk",
    "sl",
    "sm",
    "sn",
    "so",
    "sq",
    "sr",
    "st",
    "su",
    "sv",
    "sw",
    "ta",
    "te",
    "tg",
    "th",
    "tr",
    "uk",
    "und",
    "ur",
    "uz",
    "vi",
    "xh",
    "yi",
    "yo",
    "zh",
    "zh-Latn",
    "zu",
]

_N_SHARDS_PER_SPLIT = {
    "en": {"train": 11264, "validation": 128},
    "af": {"train": 64, "validation": 1},
    "am": {"train": 16, "validation": 1},
    "ar": {"train": 1024, "validation": 4},
    "az": {"train": 256, "validation": 1},
    "be": {"train": 128, "validation": 1},
    "bg": {"train": 1024, "validation": 1},
    "bg-Latn": {"train": 4, "validation": 1},
    "bn": {"train": 512, "validation": 1},
    "ca": {"train": 512, "validation": 1},
    "ceb": {"train": 8, "validation": 1},
    "co": {"train": 8, "validation": 1},
    "cs": {"train": 1024, "validation": 2},
    "cy": {"train": 256, "validation": 1},
    "da": {"train": 1024, "validation": 1},
    "de": {"train": 2048, "validation": 16},
    "el": {"train": 1024, "validation": 2},
    "el-Latn": {"train": 16, "validation": 1},
    "eo": {"train": 32, "validation": 1},
    "es": {"train": 2048, "validation": 16},
    "et": {"train": 256, "validation": 1},
    "eu": {"train": 64, "validation": 1},
    "fa": {"train": 1024, "validation": 2},
    "fi": {"train": 1024, "validation": 1},
    "fil": {"train": 64, "validation": 1},
    "fr": {"train": 2048, "validation": 16},
    "fy": {"train": 16, "validation": 1},
    "ga": {"train": 16, "validation": 1},
    "gd": {"train": 16, "validation": 1},
    "gl": {"train": 128, "validation": 1},
    "gu": {"train": 64, "validation": 1},
    "ha": {"train": 8, "validation": 1},
    "haw": {"train": 2, "validation": 1},
    "hi": {"train": 1024, "validation": 2},
    "hi-Latn": {"train": 16, "validation": 1},
    "hmn": {"train": 8, "validation": 1},
    "ht": {"train": 8, "validation": 1},
    "hu": {"train": 1024, "validation": 2},
    "hy": {"train": 128, "validation": 1},
    "id": {"train": 1024, "validation": 4},
    "ig": {"train": 4, "validation": 1},
    "is": {"train": 128, "validation": 1},
    "it": {"train": 1024, "validation": 8},
    "iw": {"train": 1024, "validation": 1},
    "ja": {"train": 1024, "validation": 8},
    "ja-Latn": {"train": 8, "validation": 1},
    "jv": {"train": 8, "validation": 1},
    "ka": {"train": 256, "validation": 1},
    "kk": {"train": 256, "validation": 1},
    "km": {"train": 64, "validation": 1},
    "kn": {"train": 64, "validation": 1},
    "ko": {"train": 1024, "validation": 1},
    "ku": {"train": 16, "validation": 1},
    "ky": {"train": 64, "validation": 1},
    "la": {"train": 64, "validation": 1},
    "lb": {"train": 32, "validation": 1},
    "lo": {"train": 8, "validation": 1},
    "lt": {"train": 512, "validation": 1},
    "lv": {"train": 256, "validation": 1},
    "mg": {"train": 8, "validation": 1},
    "mi": {"train": 4, "validation": 1},
    "mk": {"train": 128, "validation": 1},
    "ml": {"train": 128, "validation": 1},
    "mn": {"train": 128, "validation": 1},
    "mr": {"train": 1024, "validation": 1},
    "ms": {"train": 512, "validation": 1},
    "mt": {"train": 128, "validation": 1},
    "my": {"train": 64, "validation": 1},
    "ne": {"train": 256, "validation": 1},
    "nl": {"train": 1024, "validation": 4},
    "no": {"train": 1024, "validation": 1},
    "ny": {"train": 4, "validation": 1},
    "pa": {"train": 32, "validation": 1},
    "pl": {"train": 1024, "validation": 4},
    "ps": {"train": 16, "validation": 1},
    "pt": {"train": 1024, "validation": 4},
    "ro": {"train": 1024, "validation": 2},
    "ru": {"train": 4096, "validation": 32},
    "ru-Latn": {"train": 32, "validation": 1},
    "sd": {"train": 64, "validation": 1},
    "si": {"train": 64, "validation": 1},
    "sk": {"train": 512, "validation": 1},
    "sl": {"train": 256, "validation": 1},
    "sm": {"train": 4, "validation": 1},
    "sn": {"train": 8, "validation": 1},
    "so": {"train": 64, "validation": 1},
    "sq": {"train": 128, "validation": 1},
    "sr": {"train": 256, "validation": 1},
    "st": {"train": 2, "validation": 1},
    "su": {"train": 4, "validation": 1},
    "sv": {"train": 1024, "validation": 2},
    "sw": {"train": 32, "validation": 1},
    "ta": {"train": 256, "validation": 1},
    "te": {"train": 128, "validation": 1},
    "tg": {"train": 64, "validation": 1},
    "th": {"train": 1024, "validation": 1},
    "tr": {"train": 1024, "validation": 4},
    "uk": {"train": 1024, "validation": 2},
    "und": {"train": 3072, "validation": 32},
    "ur": {"train": 128, "validation": 1},
    "uz": {"train": 32, "validation": 1},
    "vi": {"train": 1024, "validation": 4},
    "xh": {"train": 2, "validation": 1},
    "yi": {"train": 16, "validation": 1},
    "yo": {"train": 2, "validation": 1},
    "zh": {"train": 1024, "validation": 2},
    "zh-Latn": {"train": 8, "validation": 1},
    "zu": {"train": 8, "validation": 1},
}

def write_travelweb_data(path, split=None, travelweb_trie=None):
    with gzip.open(open(path, "rb"), "rt", encoding="utf-8") as fp, open(f"{split}/data.tsv", "a", encoding="utf-8") as out_fp:
        for line in fp:
            if line:
                example = json.loads(line)
                
                ex_url = example["url"]
                m = re.match("(.*)//(.*)", ex_url)
                if m:
                    ex_url = m.groups()[-1].strip('/').lower()
                
                in_trie = False
                for _ in travelweb_trie.iterkeys(ex_url):
                    in_trie = True
                    break
                
                if in_trie:
                    out_fp.write(line)
        out_fp.close()

def download_file(url_iter, DOWNLOAD_DIR=None, split=None):  
    idx, url = url_iter
    
    for i in range(6):
        try:
            wget.download(url, f"{DOWNLOAD_DIR}/{split}_data_file_{idx}.json.gz")
            break
        except Exception as e:
            try:
                shutil.rmtree(f"{DOWNLOAD_DIR}/{split}_data_file_{idx}.json.gz")
            except:
                pass
            print(url, e)

def check_process_and_terminate(results, p, time_out=1800, name="web_download"):
    TIMEOUT = time_out
    time_to_wait = TIMEOUT # initial time to wait
    start_time = time.time()
    for i, (value, result) in enumerate(results):
        try:
            result.get(time_to_wait) # wait for up to time_to_wait seconds
        except TimeoutError:
            with open(f"timeout_{name}.tsv", "a") as fp:
                fp.write(value + "\n")
                fp.close()
            print('Timeout for thread = ', i)
    
        # how much time has exprired since we began waiting?
        t = time.time() - start_time
        time_to_wait = TIMEOUT - t
        if time_to_wait < 0:
            time_to_wait = 0
    p.terminate() # all processes, busy or idle, will be terminated
    p.close()
    p.join()

data_urls = {}
for split in ["train", "validation"]:
    data_urls[split] = [
        _DATA_URL.format(
            language=lang,
            split_suffix="-validation" if split == "validation" else "",
            index=index,
            n_shards=_N_SHARDS_PER_SPLIT[lang][split],
        )
        for lang in _LANGUAGES
        for index in range(_N_SHARDS_PER_SPLIT[lang][split])
    ]

urls = []
with open("TravelWebUrls.tsv", "r", encoding="utf8") as fp:
    for url in fp:
        url = url.strip()
        m = re.match("(.*)//(.*)", url)
        url = m.groups()[-1].strip('/').lower()
        urls.append(sys.intern(url))
    fp.close()

travelweb_trie = marisa_trie.Trie(urls)

DOWNLOAD_DIR = "MC4_Download"
download_chunk_size = 100
for split in data_urls:
    os.makedirs(split, exist_ok=True)
    data_urls_chunked = [data_urls[split][i:i + download_chunk_size] for i in range(0, len(data_urls[split]), download_chunk_size)]
    for chunk_idx, chunk in enumerate(data_urls_chunked):
        try:
            shutil.rmtree(DOWNLOAD_DIR)
        except:
            pass
        os.makedirs(DOWNLOAD_DIR, exist_ok=True)

        p = Pool(100)
        results = [(v[1], p.apply_async(partial(download_file, DOWNLOAD_DIR=DOWNLOAD_DIR, split=split), args=(v,))) for v in enumerate(chunk)]
        check_process_and_terminate(results, p, time_out=1800, name="web_download")
        
        p = Pool(100)
        results = [(v, p.apply_async(partial(write_travelweb_data, split=split, travelweb_trie=travelweb_trie), args=(v,))) for v in list(glob(f"{DOWNLOAD_DIR}/*.json.gz"))]
        check_process_and_terminate(results, p, time_out=1800, name="process")

        # list(tqdm(p.imap_unordered(partial(download_file, DOWNLOAD_DIR=DOWNLOAD_DIR, split=split), enumerate(chunk)), desc="No. Of Urls Downloaded"))
        # list(tqdm(p.imap_unordered(partial(write_travelweb_data, split=split, travelweb_trie=travelweb_trie), list(glob(f"{DOWNLOAD_DIR}/*.json.gz"))), desc="No. Of Urls Processed"))
        # p.map(partial(write_travelweb_data, split=split, travelweb_trie=travelweb_trie), list(glob(f"{DOWNLOAD_DIR}/*.json.gz")))
    
    try:
        shutil.rmtree(DOWNLOAD_DIR)
    except:
        pass