import json
import os
from glob import glob
from tqdm import tqdm
import random

random.seed(42)

from sklearn.model_selection import train_test_split

def get_votes(x):
    if type(x['votes']) == int:
        votes = x['votes']
    elif type(x['votes']) == str:
        votes = int(x['votes'].split(" ")[0].replace(",",""))
    else:
        raise NotImplementedError
    return votes

def get_level(x):
    if type(x['level']) == int:
        level = x['level']
    elif type(x['level']) == str:
        level = int(x['level'].split("_")[1])
    else:
        raise NotImplementedError    
    return level

def collate_TripAdvisorQnA(in_path, out_path):
    with open(out_path, "w", encoding="utf-8", errors="ignore") as out_fp:
        files = glob(f"{in_path}/*.json")
        all_data = []
        for _file in tqdm(files):
            with open(_file, "r", encoding="utf-8", errors="ignore") as fp:
                data = json.load(fp)
                for key in data:
                    if data[key]['question']['fulltext'].strip()!="" and len(data[key]['answers'])!=0:
                        data[key]['answers'] = sorted(data[key]['answers'], reverse=True, key=lambda x: get_votes(x))
                        if get_votes(data[key]['answers'][0]) == 0:
                            data[key]['answers'] = sorted(data[key]['answers'], reverse=True, key=lambda x: get_level(x))
                        all_data.append(data[key])
                fp.close()
        
        random.shuffle(all_data)
        for line in tqdm(all_data):
            out_fp.write(json.dumps(line) + "\n")
        out_fp.close()

def train_val_test_split(data_folder, train_finetune_split=False):
    count = 0
    with open(os.path.join(data_folder, "data.tsv"), "r", encoding="utf-8", errors="ignore") as fp:
        for line in fp:
            count += 1
        fp.close()

    print(f"Data Dir: {data_folder}")
    print(f"Total instances: {count}")

    n_test = int(min(15000, int(0.15*count)))
    train_idx, val_test_idx = train_test_split(list(range(count)), test_size=n_test, random_state=42)
    val_idx, test_idx = train_test_split(val_test_idx, test_size=n_test//2, random_state=42)

    if train_finetune_split:
        pretrain_idx, finetune_idx = train_test_split(train_idx, test_size=0.3, random_state=42)

    idx_dict = {}

    train_writer = open(os.path.join(data_folder, "train.tsv"), "w", encoding="utf-8", errors="ignore")
    with open(os.path.join(data_folder, "train_count.tsv"), "w", encoding="utf-8", errors="ignore") as fp:
        fp.write(str(len(train_idx)))
        fp.close()

    for idx in train_idx:
        idx_dict[idx] = [train_writer]

    val_writer = open(os.path.join(data_folder, "dev.tsv"), "w", encoding="utf-8", errors="ignore")
    with open(os.path.join(data_folder, "dev_count.tsv"), "w", encoding="utf-8", errors="ignore") as fp:
        fp.write(str(len(val_idx)))
        fp.close()

    for idx in val_idx:
        idx_dict[idx] = [val_writer]
    
    test_writer = open(os.path.join(data_folder, "test.tsv"), "w", encoding="utf-8", errors="ignore")
    with open(os.path.join(data_folder, "test_count.tsv"), "w", encoding="utf-8", errors="ignore") as fp:
        fp.write(str(len(test_idx)))
        fp.close()

    for idx in test_idx:
        idx_dict[idx] = [test_writer]

    if train_finetune_split:
        pretrain_writer = open(os.path.join(data_folder, "pretrain.tsv"), "w", encoding="utf-8", errors="ignore")
        with open(os.path.join(data_folder, "pretrain_count.tsv"), "w", encoding="utf-8", errors="ignore") as fp:
            fp.write(str(len(pretrain_idx)))
            fp.close()

        for idx in pretrain_idx:
            idx_dict[idx].append(pretrain_writer)

        finetune_writer = open(os.path.join(data_folder, "finetune.tsv"), "w", encoding="utf-8", errors="ignore")
        with open(os.path.join(data_folder, "finetune_count.tsv"), "w", encoding="utf-8", errors="ignore") as fp:
            fp.write(str(len(finetune_idx)))
            fp.close()

        for idx in finetune_idx:
            idx_dict[idx].append(finetune_writer)

    with open(os.path.join(data_folder, "data.tsv"), "r", encoding="utf-8", errors="ignore") as fp:
        for idx, line in enumerate(tqdm(fp)):
            for writer in idx_dict[idx]:
                writer.write(line)
        fp.close()

    train_writer.close()
    val_writer.close()
    test_writer.close()

collate_TripAdvisorQnA("data/TripAdvisorQnA/question_data", "data/TripAdvisorQnA/data.tsv")

train_val_test_split("data/TravelBlog")
train_val_test_split("data/TravelWeb")
train_val_test_split("data/TravelWikiQA", train_finetune_split=True)
train_val_test_split("data/TripAdvisorQnA", train_finetune_split=True)