from distutils.log import error
import json
import os
import statistics
import pandas as pd
import random
import matplotlib.pyplot as plt
from collections import Counter
import numpy as np

def travelblog_clean(line):
    original_line = line
    line = line.strip().split("\t")
    text_a = line[-1].replace("#TAB#", "\t").replace("#T#", "\t").replace("#N#", "\n").replace("#R#", "\r").lower()
    
    if len(line) > 3: title = line[2]
    else: return None
    
    try:
        text_a = eval(text_a)
        if len(text_a) > 1 and type(text_a) == list:
            text_a = max(text_a, key=len)
    except:
        pass
    
    if text_a == "" or text_a == [] or not isinstance(text_a, str):
        return None
    
    return original_line


keyval_dict = {}
value_dict = {}
comparison_value_dict = {}
comparison_keyval_dict = {}

def travelwiki_clean(line):
    original_line = line

    line = line.strip().split("\t")[1]
    try:
        line = json.loads(line)

    except TypeError:
        line = json.loads(str(line))

    if line == {} or line['text'].strip() == "" or line['params'] == {}:
        return None

    extracted_params = {}
    for key, value in line['params'].items():
        if type(key) == int or type(key) == float or (key.replace('.','').isnumeric()) or (type(key)==str and len(key)<=1) or (type(value)==str and len(value)<=1):
            continue
        else:
            # Removing newline characters and extra whitespaces from the keyword and value
            cleaned_key = key.lower().strip()
            cleaned_key = cleaned_key.replace("\n","")
            cleaned_value = value.lower().strip()
            cleaned_value = cleaned_value.replace("\n","")
            extracted_params[cleaned_key]=cleaned_value

    if len(extracted_params) == 0:
        return None
        
    key_value_pair_list = []
    for key,value in extracted_params.items():
        key_value_pair_list.append((key,value))
        if value not in comparison_value_dict:
            comparison_value_dict[value]=0
        comparison_value_dict[value]+=1
        kvp = (key,value)
        if kvp not in comparison_keyval_dict:
            comparison_keyval_dict[kvp]=0
        comparison_keyval_dict[kvp]+=1

    chosen_key_value_pair = None

    while len(key_value_pair_list)!=0:
        random_choice = random.choice(key_value_pair_list)
        random_value = random_choice[1]
        if (random_value in value_dict and value_dict[random_value]>=2000) or (random_choice in keyval_dict and keyval_dict[random_choice]>=10):
            key_value_pair_list.remove(random_choice)
            continue
        else:
            chosen_key_value_pair = random_choice
            if random_value not in value_dict:
                value_dict[random_value]=0
            value_dict[random_value]+=1
            if random_choice not in keyval_dict:
                keyval_dict[random_choice]=0
            keyval_dict[random_choice]+=1
            break

    original_line = original_line.replace("\n","")
    if chosen_key_value_pair is None:
        return_line = original_line + '\t' + "###no_key###" + '\n'
    else:
        return_line = original_line + '\t' + chosen_key_value_pair[0] + '\n'

    return return_line



def wikifilter(line):
    original_line = line
    select_key = line.strip().split("\t")[-1]
    select_key = select_key.lower().strip().replace("\n","")
    select_key = str(select_key)

    if "###no_key###" in select_key:
        return None
        
    line = line.strip().split("\t")[1]
    try:
        line = json.loads(line)

    except TypeError:
        line = json.loads(str(line))

    if line == {} or line['text'].strip() == "" or line['params'] == {}:
        return None

    extracted_params = {}
    for key, value in line['params'].items():
        if type(key) == int or type(key) == float or (key.replace('.','').isnumeric()) or (type(key)==str and len(key)<=1) or (type(value)==str and len(value)<=1):
            continue
        else:
            cleaned_key = key.lower().strip()
            cleaned_key = cleaned_key.replace("\n","")
            cleaned_value = value.lower().strip()
            cleaned_value = cleaned_value.replace("\n","")
            extracted_params[cleaned_key]=cleaned_value

    if len(extracted_params) == 0:
        return None

    try:
        select_value = extracted_params[select_key]
    
    ## In case the last column has a blank key (empty string); choose a random key from the params dict
    except KeyError or IndexError:
        select_key = random.choice(list(extracted_params.keys()))
        select_value = extracted_params[select_key]

    if select_value not in comparison_value_dict:
        comparison_value_dict[select_value]=0
    comparison_value_dict[select_value]+=1
    kvp = (select_key,select_value)
    if kvp not in comparison_keyval_dict:
        comparison_keyval_dict[kvp]=0
    comparison_keyval_dict[kvp]+=1

    return original_line



def tripadvisor_clean(line):
    original_line = line
    title_presence = "Yes"
    line = line.lower()
    line = json.loads(line)
    if line == {}:
        return None, None
    if line['question']['title'].strip() == "":
        title_presence = "No"

    # removing default tripadvisor comments from the answers list
    japanese_list = ["こちらのトピックはしばらくの間投稿が無かったため",
                "トリップアドバイザー旅の掲示板をご利用いただき誠にありがとうございます",
                "トリップアドバイザーをご利用いただきありがとうございます",
                "投稿者のご依頼により原文は削除されました",
                "トリップアドバイザー コミュニティーチーム"]

    russian_list = ["эта тема закрыта для публикации новых сообщений",
                    "специалисты tripadvisor удалили",
                    "спасибо за участие на форумах tripadvisor"
                    ]

    english_list = ["this post was determined to be inappropriate",
                    "this post has been removed",
                    "message from tripadvisor staff"
                    ]

    portuguese_list = ["o pessoal do tripadvisor removeu",
                    "este tópico foi fechado a novas publicações"]

    spanish_list = ["el personal de tripadvisor ha eliminado",
                    "esta publicación ha sido eliminada por su autor",
                    "no es posible responder a este tema ya que ha sido cerrado por inactividad",
                    "me paso por aquí para darte la bienvenida al foro y te comento que he movido",
                    "tripadvisor ha retirado este mensaje"]

    french_list = ["cette discussion a été fermée en raison de son inactivité",
                    "l'équipe de tripadvisor a supprimé ce message",
                    "l'équipe tripadvisor a supprimé cette",
                    "cette discussion étant ancienne",
                    "ce message a été supprimé à la demande de l'auteur"]

    italian_list = ["il personale di tripadivisor ha rimosso questo",
                    "il topic è stato chiuso perché altri utenti hanno segnalato che",
                    "l'autore di questo messaggio ne ha richiesto la rimozione",
                    "lo staff di tripadvisor ha eliminato questo messaggio",
                    "questo post infrange il regolamento che proibisce pubblicita"]

    german_list = ["die tripadvisor-administratoren haben diesen beitrag entfernt",
                    "dieser beitrag wurde auf wunsch des verfassers entfernt",
                    "dieser beitrag wurde von den tripadvisor mitarbeitern",
                    "tripadvisor hat diesen beitrag entfernt"]
    
    comments_removal_list = english_list + japanese_list + german_list + russian_list + spanish_list + portuguese_list + french_list + italian_list


    for comment in comments_removal_list:
        comment = comment.lower()
        if comment in line['question']['fulltext'].strip():
            return None, None

    q = line['question']['fulltext'].strip()
    
    a = None

    candidate_list = []
    for ans in line['answers']:
        ans_line = ans['fulltext']
        removal_flag = 0
        for comment in comments_removal_list:
            comment = comment.lower()
            if comment in ans_line.lower():
                removal_flag=1
                break
        if removal_flag==0:
            candidate_list.append(ans)

    if candidate_list=={} or candidate_list==[]:
        return None, None
    
    for ans in candidate_list:
        a = ans['fulltext'].strip()
        break
    if a is None:
        return None, None

    return original_line, title_presence
