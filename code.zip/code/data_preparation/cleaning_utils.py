from os import remove
import unidecode 
import re
import nltk 
from nltk.corpus import stopwords 
nltk.download('stopwords')
nltk.download('words')
set_words = set(nltk.corpus.words.words())
from nltk.tokenize import word_tokenize 
from nltk.stem import WordNetLemmatizer 
from autocorrect import Speller 
from bs4 import BeautifulSoup 
from nltk.corpus import stopwords 
import spacy
import string
import json
from nltk.tag import pos_tag
import en_core_web_sm
from spacy.language import Language
from spacy_langdetect import LanguageDetector
import sys, traceback

nltk.download('averaged_perceptron_tagger')

@Language.factory("language_detector")
def get_lang_detector(nlp, name):
   return LanguageDetector()

def remove_newlines_tabs(text):
    Formatted_text = text.replace('\\n', ' ').replace('\n', ' ').replace('\t',' ').replace('\\', ' ').replace('. com', '.com')
    return Formatted_text

def strip_html_tags(text):
    soup = BeautifulSoup(text, "html.parser")
    stripped_text = soup.get_text(separator=" ")
    return stripped_text

def remove_links(text):
    remove_https = re.sub(r'http\S+', '', text)
    remove_com = re.sub(r"\ [A-Za-z]*\.com", " ", remove_https)
    return remove_com

def remove_whitespace(text):
    pattern = re.compile(r'\s+') 
    Without_whitespace = re.sub(pattern, ' ', text)
    text = Without_whitespace.replace('?', ' ? ').replace(')', ') ')
    return text

def removing_special_characters(text):
    Formatted_Text = re.sub(r"[^a-zA-Z0-9:$-,%.?!]+", ' ', text) 
    return Formatted_Text

def remove_emojis(data):
    emoj = re.compile("["
        u"\U0001F600-\U0001F64F"  # emoticons
        u"\U0001F300-\U0001F5FF"  # symbols & pictographs
        u"\U0001F680-\U0001F6FF"  # transport & map symbols
                      "]+", re.UNICODE)
    return re.sub(emoj, '', data)
