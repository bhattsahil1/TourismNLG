from random import sample
import pandas as pd
import json
import os
import sys
# from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer, util
from scipy.stats import rankdata
from statistics import mean
import torch
from torchmetrics.functional import retrieval_reciprocal_rank


task_name = 'TravelWikiQA_infoboxes'
file_path = 'outputs/output_para-2-infobox.json'
device = 'cuda' if torch.cuda.is_available() else 'cpu'
model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2', device=device)


candidates_file = open('mrr_data/'+task_name+'.tsv','r')
candidates_list = []
for line in candidates_file:
    original_line = line
    line = line.split('\t')
    candidates = line[-1].split('\a')
    candidates_list.append(candidates)

generated_file = open(file_path,'r')
comp_list = []
for line in generated_file:
    line = json.loads(line)
    comp_list.append((line['label'],line['prediction']))

reciprocal_ranks = []

for idx, (file_tuple, candidates) in enumerate(zip(comp_list,candidates_list)):
    original_label = file_tuple[0]
    predicted_label = file_tuple[1]
    sample_subset = [x.strip() for x in candidates]
    subset_length = len(sample_subset)

    sample_subset = sample_subset[-min(subset_length,10):]
    target = [False for _ in sample_subset]

    sample_subset.append(predicted_label)
    target.append(True)

    original_label_embeddings = model.encode([original_label], convert_to_tensor=True, batch_size=1024)
    candidate_embeddings = model.encode(sample_subset, convert_to_tensor=True, batch_size=1024)
    print(idx)
    similarity_scores = util.pytorch_cos_sim(original_label_embeddings.cpu().detach(), candidate_embeddings.cpu().detach())
    target = torch.tensor(target)
    preds = torch.tensor(similarity_scores[0])
    print(preds)
    reciprocal_rank = retrieval_reciprocal_rank(preds, target)
    reciprocal_rank = reciprocal_rank.item()
    reciprocal_ranks.append(reciprocal_rank)

print("Mean Reciprocal Rank")
print(mean(map(float,reciprocal_ranks)))



