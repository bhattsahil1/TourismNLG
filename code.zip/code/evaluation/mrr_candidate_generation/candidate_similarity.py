import re
from sentence_transformers import SentenceTransformer, util
import numpy as np
import torch

class SimilarityModel():
    def __init__(self):
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2', device=self.device)
        self.model.max_seq_length = 32
        self.cache = {}
    
    def sentence_embedding(self, sentences):
        return self.model.encode(sentences, convert_to_tensor=True, batch_size=4096)

    def cosine_similarity(self, sentence1, sentence2, cache_key, use_cache=True):
        sentence_embeddings1 = self.sentence_embedding(sentence1).cpu().detach()
        
        if use_cache:
            if cache_key not in self.cache:
                self.cache[cache_key] = self.sentence_embedding(sentence2).cpu().detach()    
            sentence_embeddings2 = self.cache[cache_key]
        
        else:
            sentence_embeddings2 = self.sentence_embedding(sentence2).cpu().detach()
        
        return util.pytorch_cos_sim(sentence_embeddings1, sentence_embeddings2)
    
    def delete_cache(self):
        del self.cache
        self.cache = {}
        return

model = SimilarityModel()

def generate_topkcandidates(target, candidates, topk=10, cache_key="", use_cache=True):

    if len(candidates) == 0:
        return []

    cleaned_candidates = []
    for candidate in candidates:
        cleaned_candidates.append(candidate.replace("\t","").replace("\n",""))

    scores = model.cosine_similarity([target], cleaned_candidates, cache_key, use_cache)
    scores = scores.cpu().detach().numpy()

    scores = scores[0]
    scores = np.argsort(scores)[::-1]

    scores = scores[:200]

    negatives = [cleaned_candidates[i] for i in scores if cleaned_candidates[i] != target]
    negatives = negatives[:topk]

    return negatives