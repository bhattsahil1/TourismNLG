import os
import pickle as pkl
import json
from candidate_similarity import generate_topkcandidates, model
from tqdm import tqdm
import random

random.seed(42)

datasets = [
        (
            'data/TravelBlog',
            'mrr_targets/TravelBlog_titles',
            'splits/language_specific_splits/TravelBlog/test.pkl',
            'mrr_data/TravelBlog_titles.tsv',
        ), 
        (
            'data/TravelWikiQA',
            'mrr_targets/TravelWikiQA_infoboxes',
            'splits/language_specific_splits/TravelWikiQA/test.pkl',
            'mrr_data/TravelWikiQA_infoboxes.tsv',
        ),
        (
            'data/TripAdvisorQnA',
            'mrr_targets/TripAdvisorQnA_titles',
            'splits/language_specific_splits/TripAdvisorQnA/test.pkl',
            'mrr_data/TripAdvisorQnA_titles.tsv',
        ),
        (
            'data/TravelWikiQA',
            'mrr_targets/TravelWikiQA_paragraphs',
            'splits/language_specific_splits/TravelWikiQA/test.pkl',
            'mrr_data/TravelWikiQA_paragraphs.tsv',
        )
        (
            'data/TripAdvisorQnA',
            'mrr_targets/TripAdvisorQnA_answers',
            'splits/language_specific_splits/TripAdvisorQnA/test.pkl',
            'mrr_data/TripAdvisorQnA_answers.tsv',
        )
]

os.makedirs("mrr_data", exist_ok=True)

def parse_TravelBlog_Title(line):
    line = line.strip().split("\t")
    title = line[2]
    return title

def parse_TravelWikiQA_KV(line):
    line = line.replace("\n", "").split("\t")

    lang, data, select_key = line[0], line[1], line[-1]
    
    data = json.loads(data)
    params = data['params']
    extracted_params = {}
    for key, value in params.items():
        if type(key) == int or type(key) == float or (key.replace('.','').isnumeric()) or (type(key)==str and len(key)==1) or (type(value)==str and len(value)==1):
            continue
        else:
            cleaned_key = key.lower().strip().replace("\n","")
            cleaned_value = value.lower().strip().replace("\n","")
            extracted_params[cleaned_key]=cleaned_value

    select_key = select_key.lower().strip().replace("\n","")

    if "###no_key###" in select_key:
        return None, None

    return select_key, extracted_params[select_key]

def parse_TravelWikiQA_Paragraph(line):
    line = line.replace("\n", "").split("\t")

    lang, data, select_key = line[0], line[1], line[-1]
    
    data = json.loads(data)
    paragraph = data['text']
    return paragraph

def parse_TripAdvisorQnA_Title(line):
    line = json.loads(line)
    title = line['question']['title']
    return title

def parse_TripAdvisorQnA_Answer(line):
    japanese_list = ["こちらのトピックはしばらくの間投稿が無かったため",
                    "トリップアドバイザー旅の掲示板をご利用いただき誠にありがとうございます",
                    "トリップアドバイザーをご利用いただきありがとうございます",
                    "投稿者のご依頼により原文は削除されました",
                    "トリップアドバイザー コミュニティーチーム"]

    russian_list = ["эта тема закрыта для публикации новых сообщений",
                    "специалисты tripadvisor удалили",
                    "спасибо за участие на форумах tripadvisor"
                    ]

    english_list = ["this post was determined to be inappropriate",
                    "this post has been removed",
                    "message from tripadvisor staff"
                    ]

    portuguese_list = ["o pessoal do tripadvisor removeu",
                    "este tópico foi fechado a novas publicações"]

    spanish_list = ["el personal de tripadvisor ha eliminado",
                    "esta publicación ha sido eliminada por su autor",
                    "no es posible responder a este tema ya que ha sido cerrado por inactividad",
                    "me paso por aquí para darte la bienvenida al foro y te comento que he movido",
                    "tripadvisor ha retirado este mensaje"]

    french_list = ["cette discussion a été fermée en raison de son inactivité",
                    "l'équipe de tripadvisor a supprimé ce message",
                    "l'équipe tripadvisor a supprimé cette",
                    "cette discussion étant ancienne",
                    "ce message a été supprimé à la demande de l'auteur"]

    italian_list = ["il personale di tripadivisor ha rimosso questo",
                    "il topic è stato chiuso perché altri utenti hanno segnalato che",
                    "l'autore di questo messaggio ne ha richiesto la rimozione",
                    "lo staff di tripadvisor ha eliminato questo messaggio",
                    "questo post infrange il regolamento che proibisce pubblicita"]

    german_list = ["die tripadvisor-administratoren haben diesen beitrag entfernt",
                    "dieser beitrag wurde auf wunsch des verfassers entfernt",
                    "dieser beitrag wurde von den tripadvisor mitarbeitern",
                    "tripadvisor hat diesen beitrag entfernt"]
    
    comments_removal_list = english_list + japanese_list + german_list + russian_list + spanish_list + portuguese_list + french_list + italian_list
    
    line = json.loads(line)
    
    candidate_list = []
    for ans in line['answers']:
        ans_line = ans['fulltext']
        removal_flag = 0
        for comment in comments_removal_list:
            comment = comment.lower()
            if comment in ans_line.lower():
                removal_flag=1
                break
        if removal_flag==0:
            candidate_list.append(ans)

    if candidate_list=={} or candidate_list==[]:
        return None

    for ans in candidate_list:
        a = ans['fulltext'].strip()
        break
    if a is None:
        return None

    return a

for paths in datasets:
    test_file = os.path.join(paths[0], 'test.tsv')
    test_lang_pickle = pkl.load(open(paths[2], 'rb'))

    language_training_data = {}
    _, _, langfiles = os.walk(paths[1]).__next__()
    for lang_file in langfiles:
        lang = lang_file.replace('.tsv', '')
        if 'TravelWikiQA' in test_file and 'infoboxes' in paths[1]:
            language_training_data[lang] = open(os.path.join(paths[1], lang_file), 'r', encoding='utf-8').read()
        else:
            language_training_data[lang] = [c.strip() for c in open(os.path.join(paths[1], lang_file), 'r', encoding='utf-8').readlines()]
    with open(test_file, 'r', encoding='utf-8') as f, open(paths[3], 'w', encoding='utf-8') as out_f:
        data = f.readlines()
        assert len(data) == len(test_lang_pickle), print(len(data), len(test_lang_pickle))

        for line, lang in tqdm(zip(data, test_lang_pickle)):
            
            if 'TravelBlog' in test_file:
                target = parse_TravelBlog_Title(line)
                if lang in language_training_data:
                    candidates = language_training_data[lang]
                else:
                    candidates = language_training_data['en']
                    lang = "en"
                
                if len(candidates) < 20:
                    additional_candidates = random.sample(language_training_data['en'], 50)
                    candidates = candidates + additional_candidates
                    topkcandidates = generate_topkcandidates(target, candidates, topk=20, use_cache=False)
                
                else:
                    topkcandidates = generate_topkcandidates(target, candidates, topk=20, cache_key="TravelBlog" + lang)
            
            elif 'TravelWikiQA' in test_file:
                if 'infoboxes' in paths[1]:
                    key, target = parse_TravelWikiQA_KV(line)
                    if lang in language_training_data:
                        param_dict = json.loads(language_training_data[lang])
                    else:
                        param_dict = json.loads(language_training_data['en'])
                        lang = "en"
                    candidates = []
                    if key in param_dict:
                        candidates = param_dict[key]
                    
                    filtered_candidates = [candidate for candidate in candidates if candidate.strip()!=target]
                    
                    if len(filtered_candidates)<20:
                        sample_param_dict = json.loads(language_training_data['en'])
                        random_keys = random.sample(sample_param_dict.keys(),50)
                        additional_candidates = []
                        for key in random_keys:
                            additional_candidates.append(random.sample(sample_param_dict[key],1)[0])
                        candidates = candidates + additional_candidates
                        topkcandidates = generate_topkcandidates(target, candidates, topk=20, use_cache=False)
                    else:
                        topkcandidates = generate_topkcandidates(target, candidates, topk=20, cache_key="TravelWikiQAInfobox" + key + lang)

                elif 'paragraphs' in paths[1]:
                    target = parse_TravelWikiQA_Paragraph(line)
                    if lang in language_training_data:
                        candidates = language_training_data[lang]
                    else:
                        candidates = language_training_data['en']
                        lang = "en"

                    if len(candidates) < 20:
                        additional_candidates = random.sample(language_training_data['en'], 50)
                        candidates = candidates + additional_candidates
                        topkcandidates = generate_topkcandidates(target, candidates, topk=20, use_cache=False)
                    
                    else:
                        topkcandidates = generate_topkcandidates(target, candidates, topk=20, cache_key="TravelWikiQAParagraph" + lang)
            
            
            elif 'TripAdvisorQnA' in test_file:
                if 'titles' in paths[1]:
                    target = parse_TripAdvisorQnA_Title(line)
                    if lang in language_training_data:
                        candidates = language_training_data[lang]
                    else:
                        candidates = language_training_data['en']
                        lang = "en"

                    if len(candidates) < 20:
                        additional_candidates = random.sample(language_training_data['en'], 50)
                        candidates = candidates + additional_candidates
                        topkcandidates = generate_topkcandidates(target, candidates, topk=20, use_cache=False)
    
                    else:
                        topkcandidates = generate_topkcandidates(target, candidates, topk=20, cache_key="TripAdvisorQnATitle" + lang)
                
                elif 'answers' in paths[1]:
                    target = parse_TripAdvisorQnA_Answer(line)
                    if lang in language_training_data:
                        candidates = language_training_data[lang]
                    else:
                        candidates = language_training_data['en']
                        lang = "en"

                    if len(candidates) < 20:
                        additional_candidates = random.sample(language_training_data['en'], 50)
                        candidates = candidates + additional_candidates
                        topkcandidates = generate_topkcandidates(target, candidates, topk=20, use_cache=False)
                    
                    else:
                        topkcandidates = generate_topkcandidates(target, candidates, topk=20, cache_key="TripAdvisorQnAAnswer" + lang)

            out_f.write(line.replace("\n","") + "\t" + '\a'.join(topkcandidates).replace("\n", "") + "\n")
        f.close()
        out_f.close()
    model.delete_cache()