import os
import pickle as pkl
import json

os.makedirs("mrr_targets", exist_ok=True)
os.makedirs("mrr_targets/TravelBlog_titles", exist_ok=True)
os.makedirs("mrr_targets/TravelWikiQA_infoboxes", exist_ok=True)
os.makedirs("mrr_targets/TravelWikiQA_paragraphs", exist_ok=True)
os.makedirs("mrr_targets/TripAdvisorQnA_titles", exist_ok=True)
os.makedirs("mrr_targets/TripAdvisorQnA_answers", exist_ok=True)

datasets = [
        (
            'data/TravelBlog',
            'splits/language_specific_splits/TravelBlog/langs',
            'splits/language_specific_splits/TravelBlog/test.pkl'
        ),
        (
            'data/TravelWikiQA',
            'splits/language_specific_splits/TravelWikiQA/langs',
            'splits/language_specific_splits/TravelWikiQA/test.pkl'
        ) 
        (
            'data/TripAdvisorQnA',
            'splits/language_specific_splits/TripAdvisorQnA/langs',
            'splits/language_specific_splits/TripAdvisorQnA/test.pkl'
        )
]

def parse_TravelBlog_Title(line):
    line = line.strip().split("\t")
    assert len(line) > 3, print(line)
    title = line[2]
    return title

def parse_TravelWikiQA_KV(line):
    line = line.replace("\n", "").split("\t")
    assert len(line) >= 3, print(line)

    lang, data, select_key = line[0], line[1], line[-1]
    
    data = json.loads(data)
    params = data['params']
    extracted_params = {}
    for key, value in params.items():
        if type(key) == int or type(key) == float or (key.replace('.','').isnumeric()) or (type(key)==str and len(key)==1) or (type(value)==str and len(value)==1):
            continue
        else:
            cleaned_key = key.lower().strip().replace("\n","")
            cleaned_value = value.lower().strip().replace("\n","")
            extracted_params[cleaned_key]=cleaned_value

    select_key = select_key.lower().strip().replace("\n","")

    return extracted_params

def parse_TravelWikiQA_Paragraph(line):
    line = line.replace("\n", "").split("\t")
    assert len(line) >= 3, print(line)

    lang, data, select_key = line[0], line[1], line[-1]
    
    data = json.loads(data)
    paragraph = data['text']
    return paragraph


def parse_TripAdvisorQnA_Title(line):
    line = json.loads(line)
    title = line['question']['title']
    return title

def parse_TripAdvisorQnA_Answer(line):
    japanese_list = ["こちらのトピックはしばらくの間投稿が無かったため",
                    "トリップアドバイザー旅の掲示板をご利用いただき誠にありがとうございます",
                    "トリップアドバイザーをご利用いただきありがとうございます",
                    "投稿者のご依頼により原文は削除されました",
                    "トリップアドバイザー コミュニティーチーム"]

    russian_list = ["эта тема закрыта для публикации новых сообщений",
                    "специалисты tripadvisor удалили",
                    "спасибо за участие на форумах tripadvisor"
                    ]

    english_list = ["this post was determined to be inappropriate",
                    "this post has been removed",
                    "message from tripadvisor staff"
                    ]

    portuguese_list = ["o pessoal do tripadvisor removeu",
                    "este tópico foi fechado a novas publicações"]

    spanish_list = ["el personal de tripadvisor ha eliminado",
                    "esta publicación ha sido eliminada por su autor",
                    "no es posible responder a este tema ya que ha sido cerrado por inactividad",
                    "me paso por aquí para darte la bienvenida al foro y te comento que he movido",
                    "tripadvisor ha retirado este mensaje"]

    french_list = ["cette discussion a été fermée en raison de son inactivité",
                    "l'équipe de tripadvisor a supprimé ce message",
                    "l'équipe tripadvisor a supprimé cette",
                    "cette discussion étant ancienne",
                    "ce message a été supprimé à la demande de l'auteur"]

    italian_list = ["il personale di tripadivisor ha rimosso questo",
                    "il topic è stato chiuso perché altri utenti hanno segnalato che",
                    "l'autore di questo messaggio ne ha richiesto la rimozione",
                    "lo staff di tripadvisor ha eliminato questo messaggio",
                    "questo post infrange il regolamento che proibisce pubblicita"]

    german_list = ["die tripadvisor-administratoren haben diesen beitrag entfernt",
                    "dieser beitrag wurde auf wunsch des verfassers entfernt",
                    "dieser beitrag wurde von den tripadvisor mitarbeitern",
                    "tripadvisor hat diesen beitrag entfernt"]
    
    comments_removal_list = english_list + japanese_list + german_list + russian_list + spanish_list + portuguese_list + french_list + italian_list
    
    line = json.loads(line)
    ans_list = []
    for ans in line['answers']:
        ans_line = ans['fulltext']
        add_flag = 1
        for comment in comments_removal_list:
            comment = comment.lower()
            if comment in ans_line.lower():
                add_flag = 0
                break

        if add_flag == 1:   
            ans_list.append(ans_line)

    return ans_list



for paths in datasets:
    test_file = os.path.join(paths[0], 'test.tsv')
    test_lang_pickle = pkl.load(open(paths[2], 'rb'))

    language_training_data = {}
    _, _, langfiles = os.walk(paths[1]).__next__()
    for lang_file in langfiles:
        if 'TravelBlog' in test_file: 
            with open(os.path.join("mrr_targets/TravelBlog_titles", lang_file), 'w', encoding='utf-8') as f:
                for t in list(set([parse_TravelBlog_Title(line) for line in open(os.path.join(paths[1], lang_file), 'r', encoding='utf-8')])):
                    if t.strip() != "":
                        f.write(t + "\n")
                f.close()

        elif 'TravelWikiQA' in test_file:
            with open(os.path.join("mrr_targets/TravelWikiQA_infoboxes", lang_file), 'w', encoding='utf-8') as f:
                infokeys = {}
                for line in open(os.path.join(paths[1], lang_file), 'r', encoding='utf-8'):
                    extracted_params = parse_TravelWikiQA_KV(line)
                    if extracted_params is None or extracted_params=={}: continue

                    for key in extracted_params.keys():
                        if key.strip()=="": continue
                        if key not in infokeys:
                            infokeys[key] = set()                    
                        infokeys[key].add(extracted_params[key])

                for key in infokeys:
                    infokeys[key] = list(infokeys[key])

                f.write(json.dumps(infokeys, ensure_ascii=False) + "\n")
                f.close()

            with open(os.path.join("mrr_targets/TravelWikiQA_paragraphs", lang_file), 'w', encoding='utf-8') as f:
                for t in list(set([parse_TravelWikiQA_Paragraph(line) for line in open(os.path.join(paths[1], lang_file), 'r', encoding='utf-8')])):
                    if t.strip() != "":
                        f.write(t + "\n")
                f.close()

        elif 'TripAdvisorQnA' in test_file:
            with open(os.path.join("mrr_targets/TripAdvisorQnA_titles", lang_file), 'w', encoding='utf-8') as f:
                for t in list(set([parse_TripAdvisorQnA_Title(line) for line in open(os.path.join(paths[1], lang_file), 'r', encoding='utf-8')])):
                    if t.strip() != "":
                        f.write(t + "\n")
                f.close()

            with open(os.path.join("mrr_targets/TripAdvisorQnA_answers", lang_file), 'w', encoding='utf-8') as f:
                list_of_lists = [parse_TripAdvisorQnA_Answer(line) for line in open(os.path.join(paths[1], lang_file), 'r', encoding='utf-8')]
                answer_list = [element for listelement in list_of_lists for element in listelement]
                print(answer_list[:10])
                for t in list(set(answer_list)):
                    if t.strip() != "":
                        f.write(t + "\n")
                f.close()