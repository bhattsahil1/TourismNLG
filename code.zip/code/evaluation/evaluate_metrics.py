import json
import re
import evaluate
import sys
from sklearn.metrics import f1_score, accuracy_score
import random
FILE = sys.argv[1]

OUTPUT_FILE = None
if len(sys)>1:
    OUTPUT_FILE = sys.argv[2]

data = open(FILE, "r", encoding="utf-8").readlines()
P = []
T = []
for line in data:
    line = json.loads(line)
    P.append(line['prediction'])
    T.append(line['label'])


if 'para-2-infobox' in FILE:
    exact_match = evaluate.load("exact_match")
    em_scores = exact_match.compute(predictions=P, references=T)
    print(em_scores)
    print(f1_score(T,P,average='macro'))
    print(accuracy_score(T,P))

    if OUTPUT_FILE is not None:
        wfile = open(OUTPUT_FILE, 'w')
        wfile.write(str(f1_score(T,P,average='macro'))+'\n')
        wfile.write(str(accuracy_score(T,P))+'\n')

else:
    rouge = evaluate.load("rouge")
    rouge_scores = rouge.compute(predictions=P, references=T)
    print(rouge_scores)

    meteor = evaluate.load("meteor")
    meteor_scores = meteor.compute(predictions=P, references=T)
    print(meteor_scores)

    if OUTPUT_FILE is not None:
        wfile = open(OUTPUT_FILE, 'w')
        wfile.write(str(rouge_scores)+'\n')
        wfile.write(str(meteor_scores)+'\n')