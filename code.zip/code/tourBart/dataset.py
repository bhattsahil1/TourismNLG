import json
import os
from argparse import ArgumentParser
from typing import Type
from tqdm import tqdm
import math
import random
import numpy as np
from itertools import cycle
import sys, traceback
import csv
import pickle

import torch
from torch.utils.data import IterableDataset, DataLoader, Dataset
from transformers import MBart50Tokenizer

from utils import mask_tokens, shift_tokens_right


class BaseDataset(IterableDataset):
    def __init__(self, args, base_data_dir, task, mode="train"):
        super(BaseDataset).__init__()
        
        self.filename = os.path.join(base_data_dir, mode + ".tsv")
        self.mapfile = os.path.join(base_data_dir, mode + "_langs.txt")
        self.tokenizer = MBart50Tokenizer.from_pretrained(args.model_chkp)
        self.max_seq_len = min(args.max_seq_len, self.tokenizer.model_max_length)
        self.task = task
        self.mode = mode
        self.task_prefix = task + ": "
        self.is_prefix_added = True
        self.total_data_points = int(open(os.path.join(base_data_dir, mode + "_count.tsv")).read())
        self.lang_map = {'ar': 'ar_AR', 'cs': 'cs_CZ', 'de': 'de_DE', 'en': 'en_XX', 'es': 'es_XX', 'et': 'et_EE', 'fi': 'fi_FI', 'fr': 'fr_XX', 'gu': 'gu_IN', 'hi': 'hi_IN', 'it': 'it_IT', 'ja': 'ja_XX', 'kk': 'kk_KZ', 'ko': 'ko_KR', 'lt': 'lt_LT', 'lv': 'lv_LV', 'my': 'my_MM', 'ne': 'ne_NP', 'nl': 'nl_XX', 'ro': 'ro_RO', 'ru': 'ru_RU', 'si': 'si_LK', 'tr': 'tr_TR', 'vi': 'vi_VN', 'zh': 'zh_CN', 'af': 'af_ZA', 'az': 'az_AZ', 'bn': 'bn_IN', 'fa': 'fa_IR', 'he': 'he_IL', 'hr': 'hr_HR', 'id': 'id_ID', 'ka': 'ka_GE', 'km': 'km_KH', 'mk': 'mk_MK', 'ml': 'ml_IN', 'mn': 'mn_MN', 'mr': 'mr_IN', 'pl': 'pl_PL', 'ps': 'ps_AF', 'pt': 'pt_XX', 'sv': 'sv_SE', 'sw': 'sw_KE', 'ta': 'ta_IN', 'te': 'te_IN', 'th': 'th_TH', 'tl': 'tl_XX', 'uk': 'uk_UA', 'ur': 'ur_PK', 'xh': 'xh_ZA', 'gl': 'gl_ES', 'sl': 'sl_SI'}
        
        # removing default tripadvisor comments from the answers list
        japanese_list = ["こちらのトピックはしばらくの間投稿が無かったため",
                    "トリップアドバイザー旅の掲示板をご利用いただき誠にありがとうございます",
                    "トリップアドバイザーをご利用いただきありがとうございます",
                    "投稿者のご依頼により原文は削除されました",
                    "トリップアドバイザー コミュニティーチーム"]

        russian_list = ["эта тема закрыта для публикации новых сообщений",
                        "специалисты tripadvisor удалили",
                        "спасибо за участие на форумах tripadvisor"
                        ]

        english_list = ["this post was determined to be inappropriate",
                        "this post has been removed",
                        "message from tripadvisor staff"
                        ]

        portuguese_list = ["o pessoal do tripadvisor removeu",
                        "este tópico foi fechado a novas publicações"]

        spanish_list = ["el personal de tripadvisor ha eliminado",
                        "esta publicación ha sido eliminada por su autor",
                        "no es posible responder a este tema ya que ha sido cerrado por inactividad",
                        "me paso por aquí para darte la bienvenida al foro y te comento que he movido",
                        "tripadvisor ha retirado este mensaje"]

        french_list = ["cette discussion a été fermée en raison de son inactivité",
                        "l'équipe de tripadvisor a supprimé ce message",
                        "l'équipe tripadvisor a supprimé cette",
                        "cette discussion étant ancienne",
                        "ce message a été supprimé à la demande de l'auteur"]

        italian_list = ["il personale di tripadivisor ha rimosso questo",
                        "il topic è stato chiuso perché altri utenti hanno segnalato che",
                        "l'autore di questo messaggio ne ha richiesto la rimozione",
                        "lo staff di tripadvisor ha eliminato questo messaggio",
                        "questo post infrange il regolamento che proibisce pubblicita"]

        german_list = ["die tripadvisor-administratoren haben diesen beitrag entfernt",
                        "dieser beitrag wurde auf wunsch des verfassers entfernt",
                        "dieser beitrag wurde von den tripadvisor mitarbeitern",
                        "tripadvisor hat diesen beitrag entfernt"]
        
        comments_removal_list = english_list + japanese_list + german_list + russian_list + spanish_list + portuguese_list + french_list + italian_list

        self.tripadvisor_comments_list = comments_removal_list

    def tokenize_text(self, text_a, text_b=None, custom_len=999999, add_task_prefix=True, lang_code="en_XX"):

        task_prefix = self.task_prefix if add_task_prefix else ""
        self.is_prefix_added = add_task_prefix
        self.tokenizer.src_lang = lang_code

        if isinstance(text_a, list):
            task_prefix = self.tokenizer.tokenize(self.task_prefix) if add_task_prefix else []
        if text_b is None:
            tokenized = self.tokenizer.encode_plus(task_prefix + text_a, None, max_length=min(self.max_seq_len, custom_len), return_special_tokens_mask=True, padding=True, truncation=True, pad_to_multiple_of=min(self.max_seq_len, custom_len), return_tensors="pt")
        else:
            tokenized = self.tokenizer.encode_plus(task_prefix + text_a, text_b, max_length=min(self.max_seq_len, custom_len), return_special_tokens_mask=True, padding=True, truncation=True, pad_to_multiple_of=min(self.max_seq_len, custom_len), return_tensors="pt")

        return {
            'input_ids': tokenized['input_ids'].squeeze(), 
            'attention_mask': tokenized['attention_mask'].squeeze(),
            'special_tokens_mask': tokenized['special_tokens_mask'].squeeze()
        }
    
    def convert_to_features(self, line, lang):
        raise NotImplementedError

    def __iter__(self):
        with open(self.filename, "r", encoding="utf-8", errors="ignore") as fp, open(self.mapfile, "r") as langfp:
            for line, lang in zip(fp, langfp):
                try:

                    stripped_lang = lang.strip().replace('\n','').lower()
                    lang_code = 'en_XX'
                    if stripped_lang in self.lang_map.keys():
                        lang_code = self.lang_map[stripped_lang]

                    featurized = self.convert_to_features(line.lower(), lang_code)
                    if featurized is not None:
                        if self.task == "language-modeling": mask_tokens(featurized, self.tokenizer, self.is_prefix_added, is_mT5=False)
                        else: shift_tokens_right(featurized, self.tokenizer)
                        
                        if self.mode == "test":
                                yield {
                                    'task': self.task,
                                    'input_ids': featurized['input_ids'], 
                                    'attention_mask': featurized['attention_mask'],
                                    'labels': featurized['label'],
                                    'decoder_attention_mask': featurized['decoder_attention_mask'],
                                    'language': lang_code
                                }
                        else:
                                featurized['label'].masked_fill_(featurized['label'] == self.tokenizer.pad_token_id, -100)
                                yield {
                                    'input_ids': featurized['input_ids'], 
                                    'attention_mask': featurized['attention_mask'],
                                    'labels': featurized['label'],
                                    'decoder_input_ids': featurized['decoder_input_ids'],
                                    'decoder_attention_mask': featurized['decoder_attention_mask'] 
                                }
                except Exception as e:
                    traceback.print_exc(file=sys.stdout)
                    print(e)
                    
            fp.close()

# TravelWeb Language Modeling Dataset - Pretraining task only
class TravelWeb_LM_Dataset(BaseDataset):
    def convert_to_features(self, line, lang):
        jsonline = json.loads(line)
        text_a = jsonline['text']
        text_a = text_a.replace("#TAB#", "\t").replace("#T#", "\t").replace("#N#", "\n").replace("#R#", "\r").replace(":", "-").strip().lower()
        text_a = text_a.strip().replace("\n"," ")
        if text_a == "":
            return None

        offset = 1
        input_ids = self.tokenizer.tokenize(text_a)
        n_parts = math.ceil(len(input_ids)//(self.max_seq_len - offset))
        random.seed(42)
        random_slice_idx = random.randint(0,n_parts)
        tokens_slice = input_ids[(self.max_seq_len - offset) * random_slice_idx:(self.max_seq_len - offset) * (random_slice_idx + 1)]
        if len(tokens_slice)==0:
            return None
        
        tokenized = self.tokenize_text(tokens_slice, text_b=None, lang_code=lang)
        tokenized['label'] = tokenized['input_ids'].detach().clone()
        tokenized['decoder_input_ids'] = tokenized['label'].detach().clone()
        tokenized['decoder_attention_mask'] = tokenized['attention_mask'].detach().clone()
        return tokenized

# TravelWikiQA Language Modeling Dataset - Pretraining task only
class TravelWikiQA_LM_Dataset(BaseDataset):
    def convert_to_features(self, line, lang):
        line = line.strip().split("\t")[1] #We take index 1 here since the field at idx 0 indicates language
        try:
            line = json.loads(line)
            if line == {} or line['text'].strip() == "":
                return None
        except:
            return None

        offset = 1
        input_ids = self.tokenizer.tokenize(line['text'].replace(":", "-").strip())
        n_parts = math.ceil(len(input_ids)//(self.max_seq_len - offset))
        random.seed(42)
        random_slice_idx = random.randint(0,n_parts)
        tokens_slice = input_ids[(self.max_seq_len - offset) * random_slice_idx:(self.max_seq_len - offset) * (random_slice_idx + 1)]
        if len(tokens_slice)==0:
            return None
        
        tokenized = self.tokenize_text(tokens_slice, text_b=None, lang_code=lang)
        tokenized['label'] = tokenized['input_ids'].detach().clone()
        tokenized['decoder_input_ids'] = tokenized['label'].detach().clone()
        tokenized['decoder_attention_mask'] = tokenized['attention_mask'].detach().clone()
        return tokenized

# TravelBlog Language Modeling Dataset - Pretraining task only
class TravelBlog_LM_Dataset(BaseDataset):
    def convert_to_features(self, line, lang):
        line = line.strip().split("\t")
        text_a = line[-1].replace("#TAB#", "\t").replace("#T#", "\t").replace("#N#", "\n").replace("#R#", "\r").lower() # Index -1 here because we only need the blog content for language modeling
        
        try:
            text_a = eval(text_a)
            if len(text_a) > 1 and type(text_a) == list:
                text_a = max(text_a, key=len)
        except:
            pass
        
        if text_a == "" or text_a == [] or not isinstance(text_a, str):
            return None

        offset = 1
        try:
            input_ids = self.tokenizer.tokenize(text_a.replace(":", "-"))
        except TypeError:
            text_a = text_a.encode('utf-8', 'replace').decode()
            input_ids = self.tokenizer.tokenize(text_a.replace(":", "-"))

        n_parts = math.ceil(len(input_ids)//(self.max_seq_len - offset))
        random.seed(42)
        random_slice_idx = random.randint(0,n_parts)
        tokens_slice = input_ids[(self.max_seq_len - offset) * random_slice_idx:(self.max_seq_len - offset) * (random_slice_idx + 1)]
        if len(tokens_slice)==0:
            return None
        
        tokenized = self.tokenize_text(tokens_slice, text_b=None, lang_code=lang)
        tokenized['label'] = tokenized['input_ids'].detach().clone()
        tokenized['decoder_input_ids'] = tokenized['label'].detach().clone()
        tokenized['decoder_attention_mask'] = tokenized['attention_mask'].detach().clone()
        return tokenized

# TripAdvisorQnA Language Modeling Dataset - Pretraining task only
class TripAdvisorQnA_LM_Dataset(BaseDataset):
    def convert_to_features(self, line, lang):
        line = json.loads(line)
        if line == {}:
            return None
    
        for comment in self.tripadvisor_comments_list:
            comment = comment.lower()
            if comment in line['question']['fulltext'].strip():
                return None

        text = line['question']['fulltext'].strip().rstrip('.')

        candidate_list = []
        for ans in line['answers']:
            ans_line = ans['fulltext']
            removal_flag = 0
            for comment in self.tripadvisor_comments_list:
                comment = comment.lower()
                if comment in ans_line.lower():
                    removal_flag=1
                    break
            if removal_flag==0:
                candidate_list.append(ans)

        if candidate_list=={} or candidate_list==[]:
            return None
        
        random.seed(42)
        a = random.choice(candidate_list)['fulltext'].strip()
        if a is None:
            return None
        text += ". " + a

        if text == "":
            return None

        tokenized = self.tokenize_text(text.replace(":", "-"), text_b=None, lang_code=lang)
        tokenized['label'] = tokenized['input_ids'].detach().clone()
        tokenized['decoder_input_ids'] = tokenized['label'].detach().clone()
        tokenized['decoder_attention_mask'] = tokenized['attention_mask'].detach().clone()
        return tokenized

# Task: Blog Title Generation
class TravelBlog_TitleGen_Dataset(BaseDataset):
    def convert_to_features(self, line, lang):
        line = line.strip().split("\t")
        text_a = line[-1].replace("#TAB#", "\t").replace("#T#", "\t").replace("#N#", "\n").replace("#R#", "\r").lower()

        if len(line) > 3: title = line[2]
        else: return None
        
        try:
            text_a = eval(text_a)
            if len(text_a) > 1 and type(text_a) == list:
                text_a = max(text_a, key=len)
        except:
            pass
        
        if text_a == "" or text_a == [] or not isinstance(text_a, str):
            return None

        try:
            input_tok = self.tokenize_text(text_a.replace(":", "-"), lang_code=lang)
        except TypeError:
            text_a = text_a.encode('utf-8', 'replace').decode()
            input_tok = self.tokenize_text(text_a.replace(":", "-"), lang_code=lang)

        target_tok = self.tokenize_text(title, add_task_prefix=False, lang_code=lang)
        
        return {
            'input_ids': input_tok['input_ids'], 
            'attention_mask': input_tok['attention_mask'],
            'label': target_tok['input_ids'],
            'decoder_attention_mask': target_tok['attention_mask'] 
        }

# Task: Paragraph Generation
class TravelWikiQA_infobox2para_Dataset(BaseDataset):
    def convert_to_features(self, line, lang):
        line = line.strip().split("\t")[1] # We take index 1 here since the field at idx 0 indicates language
        try:
            line = json.loads(line)

        except TypeError:
            line = json.loads(str(line))

        if line == {} or line['text'].strip() == "" or line['params'] == {}:
            return None

        extracted_params = {}
        for key, value in line['params'].items():
            if type(key) == int or type(key) == float or (key.replace('.','').isnumeric()) or (type(key)==str and len(key)==1) or (type(value)==str and len(value)==1):
                continue
            else:
                cleaned_key = key.lower().strip()
                cleaned_key = cleaned_key.replace("\n","")
                cleaned_value = value.lower().strip()
                cleaned_value = cleaned_value.replace("\n","")
                extracted_params[cleaned_key]=cleaned_value

        if len(extracted_params)==0:
            return None


        infobox = []
        for key, value in extracted_params.items():
            infobox.append(key + "-" + value)
        infobox = "; ".join(infobox)

        input_tok = self.tokenize_text(infobox.replace(":", "-"), lang_code=lang)
        target_tok = self.tokenize_text(line['text'].strip(), add_task_prefix=False, lang_code=lang)
        
        return {
            'input_ids': input_tok['input_ids'], 
            'attention_mask': input_tok['attention_mask'],
            'label': target_tok['input_ids'],
            'decoder_attention_mask': target_tok['attention_mask'] 
        }

# Task: Passage QA
class TravelWikiQA_para2infobox_Dataset(BaseDataset):
    def convert_to_features(self, line, lang):
        select_key = line.strip().split("\t")[-1]
        select_key = select_key.lower().strip().replace("\n","")
        select_key = str(select_key)

        if "###no_key###" in select_key:
            return None
            
        line = line.strip().split("\t")[1]
        try:
            line = json.loads(line)

        except TypeError:
            line = json.loads(str(line))

        if line == {} or line['text'].strip() == "" or line['params'] == {}:
            return None

        extracted_params = {}
        for key, value in line['params'].items():
            if type(key) == int or type(key) == float or (key.replace('.','').isnumeric()) or (type(key)==str and len(key)==1) or (type(value)==str and len(value)==1):
                continue
            else:
                cleaned_key = key.lower().strip()
                cleaned_key = cleaned_key.replace("\n","")
                cleaned_value = value.lower().strip()
                cleaned_value = cleaned_value.replace("\n","")
                extracted_params[cleaned_key]=cleaned_value

        if len(extracted_params) == 0:
            return None

        try:
            select_value = extracted_params[select_key]
        
        ## In case the last column has a blank key (empty string); choose a random key from the params dict
        except KeyError or IndexError:
            select_key = random.choice(list(extracted_params.keys()))
            select_value = extracted_params[select_key]

        input_tok = self.tokenize_text(select_key.replace(":", "-"), text_b=line['text'].replace(":", "-").strip(),lang_code=lang)
        target_tok = self.tokenize_text(select_value, add_task_prefix=False,lang_code=lang)

        return {
            'input_ids': input_tok['input_ids'], 
            'attention_mask': input_tok['attention_mask'],
            'label': target_tok['input_ids'],
            'decoder_attention_mask': target_tok['attention_mask'] 
        }

# Task: Long QA
class TripAdvisorQnA_AnswerGen_Dataset(BaseDataset):
    def convert_to_features(self, line, lang):
        line = json.loads(line)
        if line == {}:
            return None

        for comment in self.tripadvisor_comments_list:
            comment = comment.lower()
            if comment in line['question']['fulltext'].strip():
                return None
        
        q = line['question']['fulltext'].strip()
        a = None

        candidate_list = []
        for ans in line['answers']:
            ans_line = ans['fulltext']
            removal_flag = 0
            for comment in self.tripadvisor_comments_list:
                comment = comment.lower()
                if comment in ans_line.lower():
                    removal_flag=1
                    break
            if removal_flag==0:
                candidate_list.append(ans)

        if candidate_list=={} or candidate_list==[]:
            return None

        for ans in candidate_list:
            a = ans['fulltext'].strip()
            break
        if a is None:
            return None

        input_tok = self.tokenize_text(q.replace(":", "-"), lang_code=lang)
        target_tok = self.tokenize_text(a, add_task_prefix=False, lang_code=lang)

        return {
            'input_ids': input_tok['input_ids'], 
            'attention_mask': input_tok['attention_mask'],
            'label': target_tok['input_ids'],
            'decoder_attention_mask': target_tok['attention_mask'] 
        }

# Task: Forum Title Generation
class TripAdvisorQnA_TitleGen_Dataset(BaseDataset):
    def convert_to_features(self, line, lang):
        line = json.loads(line)
        if line == {} or line['question']['title'].strip() == "":
            return None

        for comment in self.tripadvisor_comments_list:
            comment = comment.lower()
            if comment in line['question']['fulltext'].strip():
                return None

        qatext = line['question']['fulltext'].strip().rstrip('.')

        candidate_list = []
        for ans in line['answers']:
            ans_line = ans['fulltext']
            removal_flag = 0
            for comment in self.tripadvisor_comments_list:
                comment = comment.lower()
                if comment in ans_line.lower():
                    removal_flag=1
                    break
            if removal_flag==0:
                candidate_list.append(ans)

        if candidate_list=={} or candidate_list==[]:
            return None
        
        for ans in candidate_list:
            a = ans['fulltext'].strip()
            break
        if a is None:
            return None

        qatext += ". " + a

        input_tok = self.tokenize_text(qatext.replace(":", "-"), lang_code=lang)
        target_tok = self.tokenize_text(line['question']['title'].strip(), add_task_prefix=False, lang_code=lang)

        return {
            'input_ids': input_tok['input_ids'], 
            'attention_mask': input_tok['attention_mask'],
            'label': target_tok['input_ids'],
            'decoder_attention_mask': target_tok['attention_mask'] 
        }

# Task: For Classification Tasks (not used)
class TSV_Text2Text_Dataset(BaseDataset):
    def convert_to_features(self, line, lang):
        line = list(csv.reader([line], delimiter='\t'))[0]
        if len(line) < 2:
            return None

        input_tok = self.tokenize_text(line[0].replace(":", "-").strip())
        target_tok = self.tokenize_text(line[1].strip(), add_task_prefix=False)

        return {
            'input_ids': input_tok['input_ids'], 
            'attention_mask': input_tok['attention_mask'],
            'label': target_tok['input_ids'],
            'decoder_attention_mask': target_tok['attention_mask'] 
        }

class CombinedDataset(IterableDataset):
    def __init__(self, args, mode="train", pretraining=True, seed=42):
        self.args = args
        self.mode = mode
        self.random_state = np.random.RandomState(seed)
        self.datasets = []
        
        if "language-modeling" in args.tasks:
            self.datasets.append(TravelWeb_LM_Dataset(args, os.path.join(args.data_dir, "TravelWeb"), "language-modeling", mode=mode))
            if mode == "train":
                if pretraining:
                    self.datasets.append(TravelWikiQA_LM_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "language-modeling", mode="pretrain"))
                    self.datasets.append(TripAdvisorQnA_LM_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "language-modeling", mode="pretrain"))
                    self.datasets.append(TravelBlog_LM_Dataset(args, os.path.join(args.data_dir, "TravelBlog"), "language-modeling", mode="pretrain"))

                else:
                    self.datasets.append(TravelWikiQA_LM_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "language-modeling", mode="finetune"))
                    self.datasets.append(TripAdvisorQnA_LM_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "language-modeling", mode="finetune"))
                    self.datasets.append(TravelBlog_LM_Dataset(args, os.path.join(args.data_dir, "TravelBlog"), "language-modeling", mode="finetune"))

            else:
                self.datasets.append(TravelWikiQA_LM_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "language-modeling", mode=mode))
                self.datasets.append(TripAdvisorQnA_LM_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "language-modeling", mode=mode))
                self.datasets.append(TravelBlog_LM_Dataset(args, os.path.join(args.data_dir, "TravelBlog"), "language-modeling", mode=mode))



        if "infobox-2-para" in args.tasks:
            if mode == "train":
                if pretraining:
                    self.datasets.append(TravelWikiQA_infobox2para_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "infobox-2-para", mode="pretrain"))
                else:
                    self.datasets.append(TravelWikiQA_infobox2para_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "infobox-2-para", mode="finetune"))
            else:
                self.datasets.append(TravelWikiQA_infobox2para_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "infobox-2-para", mode=mode))

        if "para-2-infobox" in args.tasks:
            if mode == "train":
                if pretraining:
                    self.datasets.append(TravelWikiQA_para2infobox_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "para-2-infobox", mode="pretrain"))
                else:
                    self.datasets.append(TravelWikiQA_para2infobox_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "para-2-infobox", mode="finetune"))
            else:
                self.datasets.append(TravelWikiQA_para2infobox_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "para-2-infobox", mode=mode))
            
        if "blog-title-generation" in args.tasks:
            if mode == "train":
                if pretraining:
                    self.datasets.append(TravelBlog_TitleGen_Dataset(args, os.path.join(args.data_dir, "TravelBlog"), "blog-title-generation", mode="pretrain"))
                else:
                    self.datasets.append(TravelBlog_TitleGen_Dataset(args, os.path.join(args.data_dir, "TravelBlog"), "blog-title-generation", mode="finetune"))
            else:
                    self.datasets.append(TravelBlog_TitleGen_Dataset(args, os.path.join(args.data_dir, "TravelBlog"), "blog-title-generation", mode=mode))


        if "forum-title-generation" in args.tasks:
            if mode == "train":
                if pretraining:
                    self.datasets.append(TripAdvisorQnA_TitleGen_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "forum-title-generation", mode="pretrain"))
                else:
                    self.datasets.append(TripAdvisorQnA_TitleGen_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "forum-title-generation", mode="finetune"))
            else:
                self.datasets.append(TripAdvisorQnA_TitleGen_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "forum-title-generation", mode=mode))

        if "answer-generation" in args.tasks:
            if mode == "train":
                if pretraining:
                    self.datasets.append(TripAdvisorQnA_AnswerGen_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "answer-generation", mode="pretrain"))
                else:
                    self.datasets.append(TripAdvisorQnA_AnswerGen_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "answer-generation", mode="finetune"))
            else:
                self.datasets.append(TripAdvisorQnA_AnswerGen_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "answer-generation", mode=mode))

        self.total_length = sum([dataset.total_data_points for dataset in self.datasets])

    def set_epoch(self, epoch):
        self.random_state = np.random.RandomState(epoch)
    
    def __iter__(self):
        datasets = [iter(dataset) for dataset in self.datasets]
        dataset_idx = [i for i in range(len(datasets))]
        if self.mode == "train":
            while len(dataset_idx) > 0:
                d_idx = self.random_state.choice(dataset_idx)
                try:
                    yield next(datasets[d_idx])
                except StopIteration:
                    dataset_idx.remove(d_idx)
        else:
            for dataset in datasets:
                for instance in dataset:
                    yield instance

class CombinedDatasetEval(Dataset):
    def __init__(self, args, mode="dev"):
        self.args = args
        self.mode = mode
        self.datasets = []
        
        if "language-modeling" in args.tasks:
            self.datasets.append(TravelWeb_LM_Dataset(args, os.path.join(args.data_dir, "TravelWeb"), "language-modeling", mode=mode))
            self.datasets.append(TravelWikiQA_LM_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "language-modeling", mode=mode))
            self.datasets.append(TravelBlog_LM_Dataset(args, os.path.join(args.data_dir, "TravelBlog"), "language-modeling", mode=mode))
            self.datasets.append(TripAdvisorQnA_LM_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "language-modeling", mode=mode))
            
        if "infobox-2-para" in args.tasks:
            self.datasets.append(TravelWikiQA_infobox2para_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "infobox-2-para", mode=mode))

        if "para-2-infobox" in args.tasks:
            self.datasets.append(TravelWikiQA_para2infobox_Dataset(args, os.path.join(args.data_dir, "TravelWikiQA"), "para-2-infobox", mode=mode))
            
        if "blog-title-generation" in args.tasks:
            self.datasets.append(TravelBlog_TitleGen_Dataset(args, os.path.join(args.data_dir, "TravelBlog"), "blog-title-generation", mode=mode))

        if "forum-title-generation" in args.tasks:
            self.datasets.append(TripAdvisorQnA_TitleGen_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "forum-title-generation", mode=mode))

        if "answer-generation" in args.tasks:
            self.datasets.append(TripAdvisorQnA_AnswerGen_Dataset(args, os.path.join(args.data_dir, "TripAdvisorQnA"), "answer-generation", mode=mode))

        self.data = [data for dataset in self.datasets for data in dataset]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]

if __name__ == "__main__":

    parser = ArgumentParser()
    parser.add_argument("--model_chkp", default="facebook/mbart-large-50")
    parser.add_argument("--max_seq_len", default=256)
    parser.add_argument("--tasks", default="language-modeling")
    parser.add_argument("--data_dir", default="data")
    args = parser.parse_args()

    tokenizer = MBart50Tokenizer.from_pretrained(args.model_chkp)

    dataset = CombinedDataset(args, mode="train", pretraining=True)
    dataloader = DataLoader(dataset, batch_size=1, pin_memory=True)

    # idx = 0
    with open('test', 'w', encoding='utf-8') as fp:
            for batch in dataloader: 
                fp.write(tokenizer.decode(batch['input_ids'].squeeze(0), skip_special_tokens=False) + "\n")