import torch

def mask_tokens(example, tokenizer, is_prefix_added, mask_token="<extra_id_0>", mlm_probability=0.30, is_mT5=True):
    """
    Prepare masked tokens inputs for masked language modeling with prob `mlm_probability`: 80% MASK, 10% random, 10% original.
    """

    # Our mask token will change to <mask> in case of MBart-large-50
    if not is_mT5:
        mask_token = "<mask>"

    # We sample a few tokens in each sequence for MLM training (with probability `self.mlm_probability`)
    probability_matrix = torch.full(example['input_ids'].shape, mlm_probability)
    special_tokens_mask = example['special_tokens_mask'].bool()

    if is_prefix_added:
        # To avoid masking of 'language-modeling:' prefix
        if is_mT5:
            special_tokens_mask[0:4]=True
        else:
            special_tokens_mask[1:6]=True

    probability_matrix.masked_fill_(special_tokens_mask, value=0.0)
    masked_indices = torch.bernoulli(probability_matrix).bool()
    
    # 80% of the time, we replace masked input tokens with sentinel token
    indices_replaced = torch.bernoulli(torch.full(example['input_ids'].shape, 0.8)).bool() & masked_indices
    example['input_ids'][indices_replaced] = tokenizer.convert_tokens_to_ids(mask_token)

    # 10% of the time, we replace masked input tokens with random word
    indices_random = torch.bernoulli(torch.full(example['input_ids'].shape, 0.5)).bool() & masked_indices & ~indices_replaced
    random_words = torch.randint(len(tokenizer), example['input_ids'].shape, dtype=torch.long)
    example['input_ids'][indices_random] = random_words[indices_random]

    # The rest of the time (10% of the time) we keep the masked input tokens unchanged
    pass

    # -100 for subwords in label that were not masked.
    example['label'].masked_fill_(~masked_indices, -100)

    if not is_mT5:
        example['decoder_input_ids'] = example['label'].detach().clone()
        example['decoder_input_ids'].masked_fill_(example['decoder_input_ids'] == -100, tokenizer.pad_token_id)
        example['decoder_input_ids'][1:] = example['decoder_input_ids'][:-1].detach().clone()
        example['decoder_input_ids'][0] = tokenizer.eos_token_id


def shift_tokens_right(example, tokenizer):
    example['decoder_input_ids'] = example['label'].detach().clone()

    example['decoder_input_ids'].masked_fill_(example['decoder_input_ids'] == -100, tokenizer.pad_token_id)

    index_of_eos = (example['decoder_input_ids'].ne(tokenizer.pad_token_id).sum() - 1).unsqueeze(-1)
    decoder_start_tokens = example['decoder_input_ids'].gather(0, index_of_eos).squeeze()
    example['decoder_input_ids'][1:] = example['decoder_input_ids'][:-1].detach().clone()
    example['decoder_input_ids'][0] = decoder_start_tokens