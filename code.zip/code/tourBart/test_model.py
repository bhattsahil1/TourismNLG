import os
from random import sample
from tqdm import tqdm
import json

import torch
from torch.utils.data import DataLoader
from sklearn.metrics import f1_score, accuracy_score
import numpy as np
import re

def test_model(args, model, tokenizer, test_dataset):

    model.cuda()
    model.half()
    model.eval()

    test_loader = DataLoader(dataset=test_dataset, 
                    batch_size=args.eval_batch_size, 
                    pin_memory=True, 
                    drop_last=False, 
                    shuffle=False,
                    num_workers=1
                )

    for test_instance in tqdm(test_loader):
        task, input_ids, attention_mask, label, language = test_instance['task'], test_instance['input_ids'],  test_instance['attention_mask'], test_instance['labels'], test_instance['language']
        # print(input_ids)
        target_language_code = language[0] ## We are using batch size 1 for inference in case of MBart

        with torch.no_grad():
            outputs = model.generate(
                input_ids=input_ids.cuda(),
                attention_mask=attention_mask.cuda(),
                max_length=args.max_seq_len,
                eos_token_id=tokenizer.eos_token_id,
                num_return_sequences=1,
                early_stopping=args.early_stopping,
                do_sample=args.sampling,
                num_beams=args.beam_size,
                temperature=args.temperature,
                no_repeat_ngram_size=args.no_repeat_ngram_size,
                top_k=args.top_k,
                top_p=args.top_p,
                length_penalty=args.length_penalty,
                num_beam_groups=args.num_beam_groups,
                forced_bos_token_id=tokenizer.lang_code_to_id[target_language_code],
                # output_scores=True,
            )
        out_sentence = tokenizer.batch_decode(outputs, skip_special_tokens=True)
        label = tokenizer.batch_decode(label, skip_special_tokens=True)
        for out, l, t in zip(out_sentence, label, task):
            with open(os.path.join(args.output_dir, f"output_{t}.json"), "a+", encoding="utf8") as fp:
                fp.write(json.dumps({"prediction": out.strip(), "label": l}, ensure_ascii=False) + "\n")
                fp.close()

