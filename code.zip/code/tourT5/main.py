from gc import callbacks
import os
import argparse
import numpy as np
import random
import json
import logging
import wandb
import math

import torch
import torch.nn as nn

from dataset import CombinedDataset, CombinedDatasetEval
from test_model import test_model ## For MT5

from transformers import MT5Config, MT5ForConditionalGeneration, MT5Tokenizer
from transformers import Trainer, TrainingArguments, TrainerCallback

import socket
os.environ['MASTER_ADDR'] = socket.gethostbyname(socket.gethostname())


class TrainStopCallback(TrainerCallback):
    "A callback that stops training if we encounter NaN in the training loss"
    def on_step_end(self, args, state, control, **kwargs):
        reverse_list = state.log_history[::-1]
        for idx, dictval in enumerate(reverse_list):
            if "loss" in dictval.keys():
                if math.isnan(reverse_list[idx]["loss"])==True:
                    print("Stopping Training since loss is NaN")
                    control.should_training_stop=True
                    break

def run(args):
    # To ensure random seed is set
    torch.manual_seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    np.random.seed(args.seed)
    random.seed(args.seed)

    tokenizer = MT5Tokenizer.from_pretrained(args.model_chkp)
    config = MT5Config.from_pretrained(args.model_chkp,
                output_hidden_states=False
            )
    model = MT5ForConditionalGeneration.from_pretrained(args.model_chkp, config=config)
        
    if args.do_test:
        test_dataset = CombinedDatasetEval(args, mode="test")

    if args.do_train:
        train_dataset = CombinedDataset(args, mode="train", pretraining=args.do_pretrain)
        val_dataset = CombinedDatasetEval(args, mode="dev")

        args.train_steps = (train_dataset.total_length * args.epochs) // (torch.cuda.device_count() * args.train_batch_size)
        args.eval_steps = (train_dataset.total_length * args.epochs) // (torch.cuda.device_count() * args.train_batch_size * 20)
        args.save_steps = (train_dataset.total_length * args.epochs) // (torch.cuda.device_count() * args.train_batch_size * 10)

        # Write exp config to output dir
        os.makedirs(args.output_dir, exist_ok=True)
        with open(os.path.join(args.output_dir, "exp_config.json"), "w") as fp:
            json.dump(vars(args), fp)
            fp.close()
                
        training_args = TrainingArguments(
            output_dir=args.output_dir,
            num_train_epochs=args.epochs,
            per_device_train_batch_size=args.train_batch_size,
            per_device_eval_batch_size=args.eval_batch_size,
            gradient_accumulation_steps=args.grad_acc_steps,
            evaluation_strategy="steps",
            max_steps=args.train_steps,
            eval_steps=args.eval_steps,
            dataloader_num_workers=args.num_workers,
            fp16=True,
            fp16_opt_level='O2',
            fp16_full_eval=True,
            warmup_ratio=args.warmup_ratio,    
            learning_rate=args.lr,
            lr_scheduler_type=args.lr_scheduler,
            weight_decay=0.01,        
            logging_dir=os.path.join(args.output_dir, "logs"),
            logging_steps=args.logging_steps,
            save_steps=args.save_steps,
            save_total_limit=args.save_total_limit,
            load_best_model_at_end=True,
            seed=args.seed,
            ignore_data_skip=True,
            sharded_ddp=True,
            report_to=args.wandb_logging,
            local_rank=args.local_rank,
            overwrite_output_dir=True
        )

        trainer = Trainer(
            model=model,
            args=training_args,    
            train_dataset=train_dataset,
            eval_dataset=val_dataset,
            tokenizer=tokenizer,
            callbacks=[TrainStopCallback]
        )

        trainer.train()
        trainer.save_model()

    if args.do_test:
        test_model(args, model, tokenizer, test_dataset)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--train_batch_size', help='training batch size', type=int, default=8)
    parser.add_argument('--eval_batch_size', help='eval batch size', type=int, default=32)
    parser.add_argument('--lr', help='training learning rate', type=float, default=2e-5)
    parser.add_argument('--lr_scheduler', help='lr scheduler type for training', default="linear")
    parser.add_argument('--epochs', help='training epochs', type=int, default=1)
    parser.add_argument('--warmup_ratio', help='warmup ratio between 0.0 and 1.0', type=float, default=0.05)
    parser.add_argument('--train_steps', help='train steps', type=int, default=1000000)
    parser.add_argument('--eval_steps', help='eval steps', type=int, default=5000)
    parser.add_argument('--save_steps', help='save steps', type=int, default=5000)
    parser.add_argument('--logging_steps', help='logging steps', type=int, default=500)
    parser.add_argument('--num_workers', help='number of dataloader workers during training', type=int, default=4)
    parser.add_argument('--save_total_limit', help='total save limit during training', type=int, default=2)

    parser.add_argument('--grad_acc_steps', help='training gradient accumulation steps', type=int, default=1)
    parser.add_argument('--max_seq_len', help='max model sequence length', type=int, default=256)
    
    parser.add_argument('--do_train', help='initiate training', action='store_true')
    parser.add_argument('--do_pretrain', help='initiate pretraining/finetuning', action='store_true')
    parser.add_argument('--do_test', help='initiate testing', action='store_true')

    parser.add_argument('--early_stopping', help='use early stopping during test', action='store_true')
    parser.add_argument('--sampling', help='use sampling during test', action='store_true')
    parser.add_argument('--beam_size', help='beam size to use during test', type=int, default=1)
    parser.add_argument('--temperature', help='beam size to use during test', type=float, default=1.0)
    parser.add_argument('--no_repeat_ngram_size', help='beam size to use during test', type=int, default=0)
    parser.add_argument('--top_k', help='top_k to use during test', type=int, default=50)
    parser.add_argument('--top_p', help='top_p to use during test', type=float, default=1.0)
    parser.add_argument('--length_penalty', help='length penalty to use during test', type=float, default=1.0)
    parser.add_argument('--num_beam_groups', help='num_beam_groups to use during test', type=int, default=1)

    parser.add_argument('--model_chkp', help='name/path to model chkp', default="google/mt5-base")
    parser.add_argument("--tasks", help='modeling tasks', default="language-modeling")
    
    parser.add_argument('--data_dir', help='path to data')
    parser.add_argument('--output_dir', help='path to output directory', required=True)

    parser.add_argument('--seed', help='random seed', type=int, default=42)
    parser.add_argument("--local_rank", help='process local rank', type=int, default=0)
    parser.add_argument("--wandb_logging", help='set wandb logging on local rank', default = None)
    parser.add_argument("--wandb_onoff", help='set wandb tracking on/off', type=int, default=1)

    args = parser.parse_args()
    
    args.tasks = args.tasks.split(',')

    if args.do_train:
        logging.basicConfig(
            level=logging.INFO,
            handlers=[
                logging.FileHandler(os.path.join(args.output_dir, "train.log")),
                logging.StreamHandler()
            ]
        )
    torch.cuda.empty_cache()
    run(args)
