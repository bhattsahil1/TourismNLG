# Pretraining section
model_chkp="google/mt5-base"
baseDir=tourNLG ## Change base-directory here
olddate=1Jan2022
date=1Jan2022
gpus=4
export PYTHONIOENCODING=utf8


# =================================================================================
# Multi-task finetuning
output_dir=${baseDir}/outputs/${date}_finetuned_output_dir_mt5_base   ## CHANGE OUTPUT DIRECTORY HERE
mkdir -p ${output_dir}
mkdir -p logs
rm -rf logs/${date}_finetuned_output_dir_mt5_base.log
if [ -e ${baseDir}/outputs/${date}_finetuned_output_dir_mt5_base/pytorch_model.bin ]; then
	echo "Using existing finetuned model";
else
	echo "Finetuned model not found. Doing finetuning now. Check finetuning logs in logs/${date}_finetuned_output_dir_mt5_base.log"
python -m torch.distributed.launch --nproc_per_node=${gpus} ../../tourT5/main.py \
--data_dir ${baseDir}/data \
--output_dir ${output_dir} \
--train_batch_size 16 \
--eval_batch_size 32 \
--lr 3e-6 \
--epochs 3 \
--model_chkp $model_chkp \
--max_seq_len 256 \
--tasks "infobox-2-para,para-2-infobox,blog-title-generation,forum-title-generation,answer-generation" \
--do_train 2>&1 |tee -a logs/${date}_finetuned_output_dir_mt5_base.log
fi
# =================================================================================
# Testing and evaluation script

output_dir=${baseDir}/outputs/${date}_output_dir_mt5_base  ## CHANGE OUTPUT DIRECTORY HERE
mkdir -p ${output_dir}
echo "Starting Testing and evaluation ..."
echo "Check logs at logs/${date}_output_dir_mt5_base.log"
rm -rf logs/${date}_output_dir_mt5_base.log
python ../../tourT5/main.py \
--data_dir ${baseDir}/data \
--output_dir ${output_dir} \
--model_chkp ${baseDir}/outputs/${date}_finetuned_output_dir_mt5_base \
--eval_batch_size 256 \
--max_seq_len 256 \
--tasks "infobox-2-para,para-2-infobox,blog-title-generation,forum-title-generation,answer-generation" \
--beam_size 1 \
--early_stopping \
--no_repeat_ngram_size 3 \
--do_test 2>&1 |tee -a logs/${date}_output_dir_mt5_base.log

# =================================================================================
# Final metrics calculation
pip install evaluate
stored_outputs_dir=${output_dir}
results_file=${baseDir}/${date}_output_mtf_mt5_base_results.txt

rm ${results_file}
touch ${results_file}

echo "LongQA" >> ${results_file}
python ../../evaluation/evaluate_metrics.py ${stored_outputs_dir}/output_answer-generation.json ${results_file}
echo "------------------------" >> ${results_file}

echo "Blog Title Generation" >> ${results_file}
python ../../evaluation/evaluate_metrics.py ${stored_outputs_dir}/output_blog-title-generation.json ${results_file}
echo "------------------------" >> ${results_file}

echo "Forum Title Generation" >> ${results_file}
python ../../evaluation/evaluate_metrics.py ${stored_outputs_dir}/output_forum-title-generation.json ${results_file}
echo "------------------------" >> ${results_file}

echo "Paragraph Generation" >> ${results_file}
python ../../evaluation/evaluate_metrics.py ${stored_outputs_dir}/output_infobox-2-para.json ${results_file}
echo "------------------------" >> ${results_file}

echo "Passage QA" >> ${results_file}
python ../../evaluation/evaluate_metrics.py ${stored_outputs_dir}/output_para-2-infobox.json ${results_file}
echo "------------------------" >> ${results_file}